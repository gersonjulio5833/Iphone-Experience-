plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.iphoneexperience.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.iphoneexperience.launcher"
        minSdk = 31
        targetSdk = 33
        versionCode = 4
        versionName = "0.4.0"
    }

    // Chave fixa (uso pessoal): permite instalar novas versões por cima da anterior sem desinstalar.
    signingConfigs {
        getByName("debug") {
            storeFile = file("ios-launcher.keystore")
            storePassword = "iosexp123"
            keyAlias = "iosexp"
            keyPassword = "iosexp123"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
// Sem dependências externas: apenas APIs nativas do Android.
