package com.iphoneexperience.launcher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView

enum class IslandMode { NONE, MEDIA, CALL, BANNER }

/**
 * "Dynamic Island": janela flutuante (permissão "Sobrepor a outras apps") com dados REAIS:
 *  - chamadas: notificações com categoria CALL (cronómetro, atender/recusar via acções da própria notificação);
 *  - notificações: mostra durante ~4,5 s cada notificação nova (toca para abrir a app);
 *  - multimédia: sessão multimédia activa (capa, título, progresso, controlos).
 * O Zenfone 8 Flip não tem recorte na câmara frontal: a ilha flutua no topo, centrada.
 */
object IslandController : MediaHub.Listener {
    private var ctx: Context? = null
    private var wm: WindowManager? = null
    private var view: IslandView? = null
    private var prefListener: SharedPreferences.OnSharedPreferenceChangeListener? = null
    private val handler = Handler(Looper.getMainLooper())
    var banner: StatusBarNotification? = null
    private val bannerTimeout = Runnable { banner = null; refresh() }

    fun start(c: Context) {
        ctx = c.applicationContext
        wm = c.getSystemService(WindowManager::class.java)
        MediaHub.listeners.add(this)
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> refresh() }
        prefListener = l
        Prefs.get(c).sp.registerOnSharedPreferenceChangeListener(l)
        refresh()
    }

    fun stop() {
        MediaHub.listeners.remove(this)
        prefListener?.let { l -> ctx?.let { Prefs.get(it).sp.unregisterOnSharedPreferenceChangeListener(l) } }
        handler.removeCallbacks(bannerTimeout)
        banner = null
        remove()
    }

    override fun onMediaChanged() { refresh() }

    private fun findCall(): StatusBarNotification? {
        val c = ctx ?: return null
        return NotifListener.snapshot().firstOrNull {
            it.notification.category == Notification.CATEGORY_CALL && it.packageName != c.packageName
        }
    }

    fun onPosted(sbn: StatusBarNotification) {
        val c = ctx ?: return
        val p = Prefs.get(c)
        if (!p.islandEnabled || !p.islandNotifs) { refresh(); return }
        val n = sbn.notification
        if (sbn.packageName == c.packageName) return
        if (n.category == Notification.CATEGORY_CALL || n.category == Notification.CATEGORY_TRANSPORT) { refresh(); return }
        if ((n.flags and (Notification.FLAG_ONGOING_EVENT or Notification.FLAG_GROUP_SUMMARY)) != 0) return
        val ex = n.extras
        val hasText = !ex.getCharSequence(Notification.EXTRA_TITLE).isNullOrEmpty() ||
            !ex.getCharSequence(Notification.EXTRA_TEXT).isNullOrEmpty()
        if (!hasText) return
        banner = sbn
        handler.removeCallbacks(bannerTimeout)
        handler.postDelayed(bannerTimeout, 4500)
        refresh()
    }

    fun dismissBanner() { handler.removeCallbacks(bannerTimeout); banner = null; refresh() }

    fun refresh() {
        val c = ctx ?: return
        val p = Prefs.get(c)
        val call = if (p.islandCalls) findCall() else null
        val mode = when {
            call != null -> IslandMode.CALL
            banner != null -> IslandMode.BANNER
            MediaHub.hasSession() -> IslandMode.MEDIA
            else -> IslandMode.NONE
        }
        val show = p.islandEnabled && Settings.canDrawOverlays(c) && (mode != IslandMode.NONE || p.islandAlways)
        if (!show) { remove(); return }
        if (view == null) add(c)
        val v = view ?: return
        v.render(mode, call, banner)
        val lp = v.layoutParams as WindowManager.LayoutParams
        lp.y = c.dpi(p.islandOffsetDp)
        try { wm?.updateViewLayout(v, lp) } catch (e: Exception) { }
    }

    private fun add(c: Context) {
        val v = IslandView(c, wm!!)
        val lp = WindowManager.LayoutParams(
            c.dpi(IslandView.COMPACT_W), c.dpi(IslandView.COMPACT_H),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = c.dpi(Prefs.get(c).islandOffsetDp)
        try { wm?.addView(v, lp); view = v } catch (e: Exception) { view = null }
    }

    private fun remove() {
        view?.let { it.release(); try { wm?.removeView(it) } catch (e: Exception) { } }
        view = null
    }
}

class IslandView(private val c: Context, private val wm: WindowManager) : FrameLayout(c) {
    companion object {
        const val COMPACT_W = 128
        const val CALL_W = 172
        const val COMPACT_H = 36
        const val EXP_W = 352
    }

    private val handler = Handler(Looper.getMainLooper())
    private var mode = IslandMode.NONE
    private var userExpanded = false
    private var call: StatusBarNotification? = null
    private var banner: StatusBarNotification? = null
    private var anim: ValueAnimator? = null
    private var curW = 0f
    private var curH = 0f
    private var tgtExpanded = false
    private var incomingDismissed = false

    // compacto
    private val compact = FrameLayout(c)
    private val smallCover = ImageView(c)
    private val smallPhone = ImageView(c)
    private val smallTimer = TextView(c)
    private val smallEq = EqualizerView(c)

    // expandido
    private val inner = FrameLayout(c)
    private val media = FrameLayout(c)
    private val callF = FrameLayout(c)
    private val bannerF = FrameLayout(c)
    private val cover = ImageView(c)
    private val mTitle = TextView(c)
    private val mArtist = TextView(c)
    private val mEq = EqualizerView(c)
    private val tCur = TextView(c)
    private val tRem = TextView(c)
    private val bar = ProgressBarView(c)
    private val btnPrev = ImageView(c)
    private val btnPlay = ImageView(c)
    private val btnNext = ImageView(c)
    private val cIcon = ImageView(c)
    private val cName = TextView(c)
    private val cSub = TextView(c)
    private val cBtnA = TextView(c)
    private val cBtnB = TextView(c)
    private val bIcon = ImageView(c)
    private val bApp = TextView(c)
    private val bTitle = TextView(c)
    private val bText = TextView(c)

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            if (mode != IslandMode.NONE) handler.postDelayed(this, 500)
        }
    }
    private val autoCollapse = Runnable { userExpanded = false; applyState() }

    private fun ph(w: Int, h: Int) = FrameLayout.LayoutParams(c.dpi(w), c.dpi(h))
    private fun pos(w: Int, h: Int, l: Int, t: Int) = FrameLayout.LayoutParams(c.dpi(w), h.let { if (it > 0) c.dpi(it) else WRAP }).apply { leftMargin = c.dpi(l); topMargin = c.dpi(t) }

    private fun txt(t: TextView, sp: Float, color: Int, bold: Boolean = false, lines: Int = 1) {
        t.setTextColor(color)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) t.typeface = Fonts.semibold
        t.maxLines = lines
        t.ellipsize = android.text.TextUtils.TruncateAt.END
    }

    private fun roundOutline(r: Float) = object : ViewOutlineProvider() {
        override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, r) }
    }

    private fun pill(t: TextView, color: Int, label: String) {
        t.text = label
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        t.typeface = Fonts.medium
        t.gravity = Gravity.CENTER
        t.background = rounded(color, c.dp(22f))
    }

    init {
        setBackgroundColor(Color.BLACK)
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, minOf(v.height / 2f, c.dp(38f)))
            }
        }

        // ---- compacto
        smallCover.scaleType = ImageView.ScaleType.CENTER_CROP
        smallCover.clipToOutline = true
        smallCover.outlineProvider = roundOutline(c.dp(6f))
        compact.addView(smallCover, FrameLayout.LayoutParams(c.dpi(24), c.dpi(24)).apply { gravity = Gravity.CENTER_VERTICAL or Gravity.START; marginStart = c.dpi(8) })
        smallPhone.setImageResource(R.drawable.ic_phone)
        smallPhone.setColorFilter(0xFF30D158.toInt())
        compact.addView(smallPhone, FrameLayout.LayoutParams(c.dpi(18), c.dpi(18)).apply { gravity = Gravity.CENTER_VERTICAL or Gravity.START; marginStart = c.dpi(12) })
        txt(smallTimer, 14f, 0xFF30D158.toInt(), true)
        compact.addView(smallTimer, FrameLayout.LayoutParams(WRAP, WRAP).apply { gravity = Gravity.CENTER_VERTICAL or Gravity.START; marginStart = c.dpi(36) })
        compact.addView(smallEq, FrameLayout.LayoutParams(c.dpi(22), c.dpi(18)).apply { gravity = Gravity.CENTER_VERTICAL or Gravity.END; marginEnd = c.dpi(12) })
        addView(compact, FrameLayout.LayoutParams(MATCH, MATCH))

        // ---- multimédia
        val ew = EXP_W
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        cover.clipToOutline = true
        cover.outlineProvider = roundOutline(c.dp(12f))
        media.addView(cover, pos(56, 56, 20, 20))
        txt(mTitle, 17f, Color.WHITE, true); txt(mArtist, 15f, 0xB3FFFFFF.toInt())
        media.addView(mTitle, pos(210, 0, 88, 24))
        media.addView(mArtist, pos(210, 0, 88, 46))
        media.addView(mEq, pos(26, 22, ew - 46, 26))
        txt(tCur, 11f, 0x99FFFFFF.toInt()); txt(tRem, 11f, 0x99FFFFFF.toInt())
        tRem.gravity = Gravity.END
        media.addView(tCur, pos(40, 0, 20, 88))
        media.addView(bar, pos(ew - 120, 6, 60, 94))
        media.addView(tRem, pos(44, 0, ew - 64, 88))
        val sz = c.dpi(34)
        fun place(v: ImageView, res: Int, cx: Int) {
            v.setImageResource(res); v.setColorFilter(Color.WHITE)
            media.addView(v, FrameLayout.LayoutParams(sz, sz, Gravity.BOTTOM or Gravity.START).apply { leftMargin = c.dpi(cx) - sz / 2; bottomMargin = c.dpi(22) })
        }
        place(btnPrev, R.drawable.ic_prev, ew / 2 - 76)
        place(btnPlay, R.drawable.ic_pause, ew / 2)
        place(btnNext, R.drawable.ic_next, ew / 2 + 76)
        btnPrev.setOnClickListener { MediaHub.previous(); keepOpen() }
        btnNext.setOnClickListener { MediaHub.next(); keepOpen() }
        btnPlay.setOnClickListener { MediaHub.playPause(); keepOpen() }
        cover.setOnClickListener { MediaHub.openApp(); userExpanded = false; applyState() }

        // ---- chamada
        cIcon.clipToOutline = true
        cIcon.outlineProvider = roundOutline(c.dp(22f))
        callF.addView(cIcon, pos(44, 44, 20, 16))
        txt(cName, 17f, Color.WHITE, true); txt(cSub, 14f, 0xB3FFFFFF.toInt())
        callF.addView(cName, pos(240, 0, 76, 18))
        callF.addView(cSub, pos(240, 0, 76, 40))
        callF.addView(cBtnA, FrameLayout.LayoutParams(c.dpi(150), c.dpi(44), Gravity.BOTTOM or Gravity.START).apply { leftMargin = c.dpi(20); bottomMargin = c.dpi(16) })
        callF.addView(cBtnB, FrameLayout.LayoutParams(c.dpi(150), c.dpi(44), Gravity.BOTTOM or Gravity.END).apply { rightMargin = c.dpi(20); bottomMargin = c.dpi(16) })

        // ---- notificação
        bIcon.clipToOutline = true
        bIcon.outlineProvider = roundOutline(c.dp(9f))
        bannerF.addView(bIcon, pos(40, 40, 18, 16))
        txt(bApp, 12f, 0x99FFFFFF.toInt())
        txt(bTitle, 15f, Color.WHITE, true)
        txt(bText, 14f, 0xE6FFFFFF.toInt(), false, 2)
        bannerF.addView(bApp, pos(260, 0, 68, 12))
        bannerF.addView(bTitle, pos(260, 0, 68, 30))
        bannerF.addView(bText, pos(260, 0, 68, 52))

        inner.addView(media, FrameLayout.LayoutParams(MATCH, MATCH))
        inner.addView(callF, FrameLayout.LayoutParams(MATCH, MATCH))
        inner.addView(bannerF, FrameLayout.LayoutParams(MATCH, MATCH))
        addView(inner, FrameLayout.LayoutParams(c.dpi(EXP_W), MATCH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        inner.alpha = 0f
        inner.visibility = View.GONE

        setOnClickListener { onTap() }
    }

    // ---------------------------------------------------------------- lógica

    private fun onTap() {
        when (mode) {
            IslandMode.CALL -> {
                if (tgtExpanded) { try { call?.notification?.contentIntent?.send() } catch (e: Exception) { }; incomingDismissed = true; userExpanded = false; applyState() }
                else { userExpanded = true; applyState(); keepOpen() }
            }
            IslandMode.BANNER -> {
                try { banner?.notification?.contentIntent?.send() } catch (e: Exception) { }
                IslandController.dismissBanner()
            }
            IslandMode.MEDIA -> { userExpanded = !userExpanded; applyState(); if (userExpanded) keepOpen() }
            IslandMode.NONE -> { }
        }
    }

    private fun keepOpen() {
        handler.removeCallbacks(autoCollapse)
        handler.postDelayed(autoCollapse, 6000)
    }

    private fun isIncoming(n: StatusBarNotification?): Boolean {
        if (n == null) return false
        val t = n.notification.extras.getInt(Notification.EXTRA_CALL_TYPE, 0)
        val ongoing = (n.notification.flags and Notification.FLAG_ONGOING_EVENT) != 0
        return t == 1 || (t == 0 && !ongoing)
    }

    private fun callStart(n: StatusBarNotification): Long {
        val ex = n.notification.extras
        val w = n.notification.`when`
        return if (ex.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false) && w > 0) w else n.postTime
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return if (s >= 3600) (s / 3600).toString() + ":" + ((s % 3600) / 60).toString().padStart(2, '0') + ":" + (s % 60).toString().padStart(2, '0')
        else (s / 60).toString() + ":" + (s % 60).toString().padStart(2, '0')
    }

    private fun appIcon(pkg: String, size: Int): Bitmap? = try {
        Icons.render(c.packageManager.getApplicationIcon(pkg), size)
    } catch (e: Exception) { null }

    private fun appLabel(pkg: String): String = try {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    fun render(m: IslandMode, callN: StatusBarNotification?, bannerN: StatusBarNotification?) {
        if (m != mode) { userExpanded = false; if (m != IslandMode.CALL) incomingDismissed = false }
        mode = m
        call = callN
        banner = bannerN

        // compacto
        smallCover.visibility = if (m == IslandMode.MEDIA) View.VISIBLE else View.GONE
        smallPhone.visibility = if (m == IslandMode.CALL) View.VISIBLE else View.GONE
        smallTimer.visibility = if (m == IslandMode.CALL) View.VISIBLE else View.GONE
        smallEq.visibility = if (m == IslandMode.MEDIA || m == IslandMode.CALL) View.VISIBLE else View.GONE
        smallEq.color = if (m == IslandMode.CALL) 0xFF30D158.toInt() else 0xFFFA5C7C.toInt()

        // multimédia
        val art = MediaHub.art()
        if (art != null) { smallCover.clearColorFilter(); cover.clearColorFilter(); smallCover.setImageBitmap(art); cover.setImageBitmap(art) }
        else { smallCover.setImageResource(R.drawable.ic_note); smallCover.setColorFilter(0xFFFA2D48.toInt()); cover.setImageResource(R.drawable.ic_note); cover.setColorFilter(0xFFFA2D48.toInt()) }
        mTitle.text = MediaHub.title() ?: ""
        mArtist.text = MediaHub.artist() ?: ""
        val playing = MediaHub.isPlaying()
        btnPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        mEq.color = 0xFFFA5C7C.toInt()
        smallEq.setActive(playing || m == IslandMode.CALL); mEq.setActive(playing)

        // chamada
        if (callN != null) {
            val ex = callN.notification.extras
            cName.text = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            cIcon.setImageBitmap(appIcon(callN.packageName, c.dpi(44)))
            val acts = callN.notification.actions
            val incoming = isIncoming(callN)
            if (incoming) {
                pill(cBtnA, 0xFFFF453A.toInt(), acts?.firstOrNull()?.title?.toString() ?: "Recusar")
                pill(cBtnB, 0xFF30D158.toInt(), if (acts != null && acts.size > 1) acts[acts.size - 1].title.toString() else "Atender")
                cBtnB.visibility = View.VISIBLE
                cBtnA.setOnClickListener { try { acts?.firstOrNull()?.actionIntent?.send() } catch (e: Exception) { }; incomingDismissed = true; applyState() }
                cBtnB.setOnClickListener { try { acts?.lastOrNull()?.actionIntent?.send() } catch (e: Exception) { }; incomingDismissed = true; applyState() }
            } else {
                pill(cBtnA, 0xFFFF453A.toInt(), acts?.firstOrNull()?.title?.toString() ?: "Terminar")
                (cBtnA.layoutParams as FrameLayout.LayoutParams).width = c.dpi(EXP_W - 40)
                cBtnB.visibility = View.GONE
                cBtnA.setOnClickListener { try { acts?.firstOrNull()?.actionIntent?.send() } catch (e: Exception) { } }
            }
            if (incoming) (cBtnA.layoutParams as FrameLayout.LayoutParams).width = c.dpi(150)
        }

        // notificação
        if (bannerN != null) {
            val ex = bannerN.notification.extras
            bIcon.setImageBitmap(appIcon(bannerN.packageName, c.dpi(40)))
            bApp.text = appLabel(bannerN.packageName).uppercase()
            bTitle.text = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            bText.text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        }

        media.visibility = if (m == IslandMode.MEDIA) View.VISIBLE else View.GONE
        callF.visibility = if (m == IslandMode.CALL) View.VISIBLE else View.GONE
        bannerF.visibility = if (m == IslandMode.BANNER) View.VISIBLE else View.GONE
        tick()
        applyState()
        handler.removeCallbacks(ticker)
        if (m != IslandMode.NONE) handler.post(ticker)
    }

    private fun tick() {
        when (mode) {
            IslandMode.MEDIA -> {
                val d = MediaHub.duration(); val pos = MediaHub.position()
                bar.fraction = if (d > 0) (pos.toFloat() / d).coerceIn(0f, 1f) else 0f
                tCur.text = fmt(pos)
                tRem.text = if (d > 0) "-" + fmt(d - pos) else ""
            }
            IslandMode.CALL -> {
                val n = call ?: return
                val incoming = isIncoming(n)
                val t = if (incoming) "" else fmt(System.currentTimeMillis() - callStart(n))
                smallTimer.text = t
                cSub.text = if (incoming) "Chamada recebida" else t
            }
            else -> { }
        }
    }

    private fun targetHeightDp(): Int = when (mode) {
        IslandMode.MEDIA -> 168
        IslandMode.CALL -> if (isIncoming(call)) 128 else 120
        IslandMode.BANNER -> 112
        IslandMode.NONE -> COMPACT_H
    }

    private fun wantExpanded(): Boolean = when (mode) {
        IslandMode.BANNER -> true
        IslandMode.CALL -> userExpanded || (isIncoming(call) && !incomingDismissed)
        IslandMode.MEDIA -> userExpanded
        IslandMode.NONE -> false
    }

    private fun applyState() {
        val e = wantExpanded()
        val wDp = if (e) EXP_W else if (mode == IslandMode.CALL) CALL_W else COMPACT_W
        val hDp = if (e) targetHeightDp() else COMPACT_H
        val w1 = c.dp(wDp.toFloat()); val h1 = c.dp(hDp.toFloat())
        val lp = layoutParams as? WindowManager.LayoutParams ?: return
        val firstLayout = curW == 0f
        if (firstLayout) { curW = lp.width.toFloat(); curH = lp.height.toFloat() }
        val changedExpansion = e != tgtExpanded
        tgtExpanded = e
        val w0 = curW; val h0 = curH
        anim?.cancel()
        val dur = if (Prefs.get(c).animations) 520L else 0L
        if (e) { inner.visibility = View.VISIBLE }
        val fromAlpha = inner.alpha
        val toAlpha = if (e) 1f else 0f
        val fromCompact = compact.alpha
        val toCompact = if (e) 0f else 1f
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = dur
            interpolator = if (changedExpansion) SPRING else SPRING_SOFT
            addUpdateListener { a ->
                val t = a.animatedValue as Float
                curW = w0 + (w1 - w0) * t
                curH = h0 + (h1 - h0) * t
                lp.width = curW.toInt().coerceAtLeast(1)
                lp.height = curH.toInt().coerceAtLeast(1)
                try { wm.updateViewLayout(this@IslandView, lp) } catch (ex: Exception) { }
                val tl = a.animatedFraction.coerceIn(0f, 1f)
                inner.alpha = fromAlpha + (toAlpha - fromAlpha) * tl
                compact.alpha = fromCompact + (toCompact - fromCompact) * tl
                val sc = 0.92f + 0.08f * inner.alpha
                inner.scaleX = sc; inner.scaleY = sc
                invalidateOutline()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { if (!tgtExpanded) inner.visibility = View.GONE }
            })
            start()
        }
        if (!e) handler.removeCallbacks(autoCollapse)
    }

    fun release() {
        handler.removeCallbacksAndMessages(null)
        anim?.cancel()
        smallEq.setActive(false); mEq.setActive(false)
    }
}

/** Barras animadas (equalizador / onda de áudio). */
class EqualizerView(c: Context) : View(c) {
    var color = 0xFFFA5C7C.toInt()
        set(v) { field = v; paint.color = v; invalidate() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFA5C7C.toInt() }
    private var active = false
    private var phase = 0f
    private val anim = ValueAnimator.ofFloat(0f, (Math.PI * 2).toFloat()).apply {
        duration = 900; repeatCount = ValueAnimator.INFINITE
        interpolator = android.view.animation.LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    fun setActive(a: Boolean) {
        active = a
        if (a && !anim.isStarted) anim.start() else if (!a) { anim.cancel(); invalidate() }
    }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val n = 5
        val gap = width * 0.10f
        val bw = (width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val f = if (active) 0.30f + 0.70f * Math.abs(Math.sin((phase + i * 0.8f).toDouble())).toFloat() else 0.28f
            val bh = height * f
            val x = i * (bw + gap)
            cv.drawRoundRect(x, (height - bh) / 2f, x + bw, (height + bh) / 2f, bw / 2f, bw / 2f, paint)
        }
    }
}

class ProgressBarView(c: Context) : View(c) {
    var fraction = 0f
        set(v) { field = v; invalidate() }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    override fun onDraw(cv: Canvas) {
        val r = height / 2f
        cv.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, track)
        cv.drawRoundRect(0f, 0f, width * fraction, height.toFloat(), r, r, fill)
    }
}
