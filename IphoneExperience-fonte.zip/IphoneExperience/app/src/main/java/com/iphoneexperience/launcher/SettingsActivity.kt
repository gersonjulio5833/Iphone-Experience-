package com.iphoneexperience.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Definições do launcher com linguagem visual inspirada no iOS (listas agrupadas). */
class SettingsActivity : Activity() {
    private lateinit var prefs: Prefs
    private var dark = false
    private var cBg = 0; private var cCard = 0; private var cText = 0; private var cSub = 0; private var cSep = 0
    private val blue = 0xFF0A84FF.toInt()
    private lateinit var list: LinearLayout
    private val rows = mutableListOf<Pair<View, String>>()     // para a pesquisa
    private val groups = mutableListOf<Pair<View, List<View>>>()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = Prefs.get(this)
        window.setDecorFitsSystemWindows(false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
    }

    override fun onResume() {
        super.onResume()
        build()
    }

    // ---------------------------------------------------------------- blocos de UI

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) typeface = Fonts.bold
    }

    private fun tile(res: Int, color: Int): View {
        val f = FrameLayout(this)
        f.background = rounded(color, dp(7f))
        val iv = ImageView(this)
        iv.setImageResource(res); iv.setColorFilter(Color.WHITE)
        f.addView(iv, FrameLayout.LayoutParams(dpi(18), dpi(18), Gravity.CENTER))
        f.layoutParams = LinearLayout.LayoutParams(dpi(30), dpi(30)).apply { marginEnd = dpi(14) }
        return f
    }

    private fun group(title: String?, build: (MutableList<View>, LinearLayout) -> Unit) {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        if (title != null) {
            val h = tv(title.uppercase(), 13f, cSub)
            h.setPadding(dpi(32), dpi(22), dpi(16), dpi(6))
            wrap.addView(h)
        }
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = rounded(cCard, dp(12f))
        wrap.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply { marginStart = dpi(16); marginEnd = dpi(16) })
        val rowViews = mutableListOf<View>()
        build(rowViews, card)
        list.addView(wrap)
        groups.add(Pair(wrap, rowViews))
    }

    private fun addRow(rowViews: MutableList<View>, card: LinearLayout, v: View, key: String) {
        if (card.childCount > 0) {
            val sep = View(this)
            sep.setBackgroundColor(cSep)
            card.addView(sep, LinearLayout.LayoutParams(MATCH, 1).apply { marginStart = dpi(60) })
            rowViews.add(sep)
        }
        card.addView(v)
        rowViews.add(v)
        rows.add(Pair(v, key.lowercase()))
    }

    private fun baseRow(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dpi(14), dpi(10), dpi(14), dpi(10))
        r.minimumHeight = dpi(48)
        return r
    }

    private fun nav(rv: MutableList<View>, card: LinearLayout, res: Int, color: Int, title: String, value: String?, onClick: () -> Unit) {
        val r = baseRow()
        r.addView(tile(res, color))
        r.addView(tv(title, 17f, cText), LinearLayout.LayoutParams(0, WRAP, 1f))
        if (value != null) r.addView(tv(value, 16f, cSub))
        r.addView(tv("  ›", 20f, cSub))
        r.setOnClickListener { onClick() }
        addRow(rv, card, r, title)
    }

    private fun toggle(rv: MutableList<View>, card: LinearLayout, res: Int, color: Int, title: String, on: Boolean, onChange: (Boolean) -> Unit) {
        val r = baseRow()
        r.addView(tile(res, color))
        r.addView(tv(title, 17f, cText), LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = Switch(this)
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, c -> onChange(c) }
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        addRow(rv, card, r, title)
    }

    private fun slider(rv: MutableList<View>, card: LinearLayout, res: Int, color: Int, title: String, min: Int, max: Int, value: Int, unit: String, onChange: (Int) -> Unit) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(dpi(14), dpi(10), dpi(14), dpi(6))
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(tile(res, color))
        top.addView(tv(title, 17f, cText), LinearLayout.LayoutParams(0, WRAP, 1f))
        val vt = tv("$value$unit", 16f, cSub)
        top.addView(vt)
        r.addView(top)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = value - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { vt.text = "${p + min}$unit"; if (u) onChange(p + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        r.addView(sb, LinearLayout.LayoutParams(MATCH, WRAP).apply { marginStart = dpi(44) })
        addRow(rv, card, r, title)
    }

    private fun info(rv: MutableList<View>, card: LinearLayout, text: String) {
        val t = tv(text, 14f, cSub)
        t.setPadding(dpi(16), dpi(12), dpi(16), dpi(12))
        addRow(rv, card, t, text)
    }

    private fun segmented(rv: MutableList<View>, card: LinearLayout, res: Int, color: Int, title: String, options: List<String>, sel: Int, onChange: (Int) -> Unit) {
        val r = baseRow()
        r.addView(tile(res, color))
        r.addView(tv(title, 17f, cText), LinearLayout.LayoutParams(0, WRAP, 1f))
        val seg = LinearLayout(this)
        seg.orientation = LinearLayout.HORIZONTAL
        seg.background = rounded(if (dark) 0xFF2C2C2E.toInt() else 0xFFEEEEF0.toInt(), dp(9f))
        seg.setPadding(dpi(2), dpi(2), dpi(2), dpi(2))
        for ((i, o) in options.withIndex()) {
            val b = tv(o, 14f, if (i == sel) Color.BLACK else cText)
            b.setPadding(dpi(10), dpi(6), dpi(10), dpi(6))
            b.background = if (i == sel) rounded(Color.WHITE, dp(7f)) else null
            b.setOnClickListener { onChange(i); build() }
            seg.addView(b)
        }
        r.addView(seg)
        addRow(rv, card, r, title)
    }

    // ---------------------------------------------------------------- helpers de estado

    private fun isDefaultHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val ri = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    private fun listenerEnabled(): Boolean =
        (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)

    private fun go(i: Intent) {
        try { startActivity(i) } catch (e: Exception) { Toast.makeText(this, "Não disponível neste telemóvel", Toast.LENGTH_SHORT).show() }
    }

    private fun yn(b: Boolean) = if (b) "Activo" else "Inactivo"

    private fun appDetails() {
        go(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun openListenerSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).putExtra(
                Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                android.content.ComponentName(this, NotifListener::class.java).flattenToString()))
        } catch (e: Exception) {
            go(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
    }

    private fun restrictedHelp() {
        AlertDialog.Builder(this)
            .setTitle("Definição restrita")
            .setMessage("O Android 13 bloqueia o \"Acesso a notificações\" e outras permissões sensíveis em apps instaladas fora da Play Store. Para desbloquear:\n\n" +
                "1. Toca em \"Abrir informações da app\".\n" +
                "2. Toca nos três pontos (⋮) no canto superior direito.\n" +
                "3. Toca em \"Permitir definições restritas\" e confirma com o teu desbloqueio.\n" +
                "4. Volta aqui e toca em \"Acesso a notificações\" para o activar.\n\n" +
                "Se os três pontos não aparecerem, tenta primeiro abrir o \"Acesso a notificações\" uma vez (vai mostrar o aviso) e depois repete os passos.")
            .setPositiveButton("Abrir informações da app") { _, _ -> appDetails() }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun hiddenDialog() {
        val hid = prefs.hidden().toList()
        if (hid.isEmpty()) { Toast.makeText(this, "Não há apps ocultas", Toast.LENGTH_SHORT).show(); return }
        val labels = AppRepo.loadAll(this).associate { it.id to it.label }
        val names = hid.map { labels[it] ?: it.substringBefore('/') }.toTypedArray()
        val checked = BooleanArray(hid.size) { true }
        AlertDialog.Builder(this)
            .setTitle("Apps ocultas (desmarca para mostrar)")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Guardar") { _, _ ->
                val keep = hid.filterIndexed { i, _ -> checked[i] }.toSet()
                prefs.setHidden(keep)
                build()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------------------------------------------------------------- ecrã

    private fun build() {
        dark = prefs.isDark(this)
        cBg = if (dark) Color.BLACK else 0xFFF2F2F7.toInt()
        cCard = if (dark) 0xFF1C1C1E.toInt() else Color.WHITE
        cText = if (dark) Color.WHITE else Color.BLACK
        cSub = 0xFF8E8E93.toInt()
        cSep = if (dark) 0xFF38383A.toInt() else 0xFFE0E0E5.toInt()
        rows.clear(); groups.clear()

        val sv = ScrollView(this)
        sv.setBackgroundColor(cBg)
        sv.setOnApplyWindowInsetsListener { v, ins ->
            val b = ins.getInsets(android.view.WindowInsets.Type.systemBars())
            v.setPadding(0, b.top, 0, b.bottom); ins
        }
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        window.insetsController?.setSystemBarsAppearance(
            if (dark) 0 else android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
            android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
        )

        val title = tv("Definições", 34f, cText, true)
        title.setPadding(dpi(20), dpi(18), dpi(20), dpi(8))
        list.addView(title)

        val search = EditText(this)
        search.hint = "Pesquisar"
        search.setHintTextColor(cSub)
        search.setTextColor(cText)
        search.setSingleLine()
        search.background = rounded(if (dark) 0xFF1C1C1E.toInt() else 0x1F767680, dp(11f))
        search.setPadding(dpi(14), dpi(9), dpi(14), dpi(9))
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) { filter(e?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        list.addView(search, LinearLayout.LayoutParams(MATCH, WRAP).apply { marginStart = dpi(16); marginEnd = dpi(16); bottomMargin = dpi(10) })

        // perfil
        val prof = LinearLayout(this)
        prof.orientation = LinearLayout.HORIZONTAL
        prof.gravity = Gravity.CENTER_VERTICAL
        prof.background = rounded(cCard, dp(12f))
        prof.setPadding(dpi(14), dpi(14), dpi(14), dpi(14))
        val av = TextView(this)
        av.text = (prefs.userName.firstOrNull() ?: 'I').uppercase()
        av.setTextColor(Color.WHITE); av.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f); av.gravity = Gravity.CENTER
        av.background = oval(0xFF8E8E93.toInt())
        prof.addView(av, LinearLayout.LayoutParams(dpi(60), dpi(60)))
        val pc = LinearLayout(this); pc.orientation = LinearLayout.VERTICAL
        pc.addView(tv(if (prefs.userName.isBlank()) "Toca para definir o teu nome" else prefs.userName, 20f, cText))
        pc.addView(tv("Perfil e personalização do launcher", 14f, cSub))
        prof.addView(pc, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dpi(14) })
        prof.setOnClickListener {
            val et = EditText(this); et.setText(prefs.userName)
            AlertDialog.Builder(this).setTitle("O teu nome").setView(et)
                .setPositiveButton("OK") { _, _ -> prefs.userName = et.text.toString().trim(); build() }
                .setNegativeButton("Cancelar", null).show()
        }
        list.addView(prof, LinearLayout.LayoutParams(MATCH, WRAP).apply { marginStart = dpi(16); marginEnd = dpi(16) })
        rows.add(Pair(prof, "perfil nome personalização"))

        val green = 0xFF34C759.toInt(); val orange = 0xFFFF9F0A.toInt(); val purple = 0xFFAF52DE.toInt()
        val gray = 0xFF8E8E93.toInt(); val red = 0xFFFF3B30.toInt(); val teal = 0xFF30B0C7.toInt()

        group("Permissões e ajuda") { rv, card ->
            nav(rv, card, R.drawable.ic_lock, red, "\"Definição restrita\"? Toca aqui", null) { restrictedHelp() }
            nav(rv, card, R.drawable.ic_bell, orange, "Acesso a notificações", yn(listenerEnabled())) { openListenerSettings() }
            if (!listenerEnabled()) info(rv, card, "Se o Android disser \"Definição restrita\", é uma protecção para apps instaladas fora da Play Store. Toca na linha de cima: explica o passo a passo (⋮ › Permitir definições restritas).")
        }

        group("Launcher") { rv, card ->
            val def = isDefaultHome()
            nav(rv, card, R.drawable.ic_grid, blue, "Launcher predefinido", if (def) "Sim" else "Não") { go(Intent(Settings.ACTION_HOME_SETTINGS)) }
            if (!def) info(rv, card, "Escolhe \"iPhone Experience\" como aplicação de ecrã inicial para o usar ao carregar no botão início.")
        }

        group("Aparência") { rv, card ->
            segmented(rv, card, R.drawable.ic_sun, blue, "Tema", listOf("Auto", "Claro", "Escuro"), prefs.theme) { prefs.theme = it }
            segmented(rv, card, R.drawable.ic_grid, purple, "Ícones", listOf("Originais", "Estilo iOS"), prefs.iconStyle) { prefs.iconStyle = it }
            toggle(rv, card, R.drawable.ic_image, teal, "Efeito de profundidade (parallax)", prefs.parallax) { prefs.parallax = it }
            nav(rv, card, R.drawable.ic_image, teal, "Papel de parede", when (prefs.wallpaperMode) { 2 -> "Imagem"; 1 -> "Azul"; else -> "Inicial" }) { wallpaperDialog() }
            slider(rv, card, R.drawable.ic_grid, green, "Transparência", 0, 100, prefs.glass, "%") { prefs.glass = it }
            slider(rv, card, R.drawable.ic_grid, orange, "Tamanho dos ícones", 80, 120, prefs.iconScale, "%") { prefs.iconScale = it }
            toggle(rv, card, R.drawable.ic_grid, purple, "Mostrar nomes das apps", prefs.showLabels) { prefs.showLabels = it }
            toggle(rv, card, R.drawable.ic_play, red, "Animações", prefs.animations) { prefs.animations = it }
        }

        group("Ecrã inicial") { rv, card ->
            toggle(rv, card, R.drawable.ic_search, gray, "Mostrar botão Pesquisar", prefs.showSearch) { prefs.showSearch = it }
            toggle(rv, card, R.drawable.ic_star, orange, "Página Hoje (widgets)", prefs.todayPage) { prefs.todayPage = it }
            toggle(rv, card, R.drawable.ic_folder, blue, "Biblioteca de Apps", prefs.libraryPage) { prefs.libraryPage = it }
            nav(rv, card, R.drawable.ic_close, red, "Apps ocultas", prefs.hidden().size.toString()) { hiddenDialog() }
            nav(rv, card, R.drawable.ic_grid, blue, "Repor disposição do ecrã inicial", null) {
                AlertDialog.Builder(this).setTitle("Repor disposição?")
                    .setMessage("As pastas e a ordem dos ícones voltam ao início (por ordem alfabética).")
                    .setPositiveButton("Repor") { _, _ -> prefs.layoutJson = ""; Toast.makeText(this, "Disposição reposta", Toast.LENGTH_SHORT).show() }
                    .setNegativeButton("Cancelar", null).show()
            }
            info(rv, card, "Mantém um ícone premido e arrasta-o: para outra posição, para o dock ou para cima de outra app para criar uma pasta. Desliza para baixo (lado esquerdo = notificações, lado direito = centro de controlo, meio = pesquisa).")
        }

        group("Dynamic Island") { rv, card ->
            toggle(rv, card, R.drawable.ic_island, 0xFF1C1C1E.toInt(), "Activar", prefs.islandEnabled) { on ->
                prefs.islandEnabled = on
                if (on && !Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Permite \"Sobrepor a outras apps\"", Toast.LENGTH_LONG).show()
                    go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
            nav(rv, card, R.drawable.ic_note, red, "Sobrepor a outras apps", yn(Settings.canDrawOverlays(this))) {
                go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            nav(rv, card, R.drawable.ic_bell, orange, "Acesso a notificações e multimédia", yn(listenerEnabled())) { openListenerSettings() }
            slider(rv, card, R.drawable.ic_island, gray, "Posição vertical", 0, 80, prefs.islandOffsetDp, " dp") { prefs.islandOffsetDp = it }
            toggle(rv, card, R.drawable.ic_phone, green, "Mostrar chamadas", prefs.islandCalls) { prefs.islandCalls = it }
            toggle(rv, card, R.drawable.ic_bell, orange, "Mostrar notificações novas", prefs.islandNotifs) { prefs.islandNotifs = it }
            toggle(rv, card, R.drawable.ic_island, gray, "Mostrar sem música (só visual)", prefs.islandAlways) { prefs.islandAlways = it }
            info(rv, card, "A ilha mostra dados reais: música activa, chamadas (a partir da notificação da chamada) e notificações novas. Precisa de \"Acesso a notificações\" e \"Sobrepor a outras apps\". O Zenfone 8 Flip não tem recorte para a câmara frontal, por isso a ilha fica no topo, centrada.")
        }

        group("Notificações") { rv, card ->
            nav(rv, card, R.drawable.ic_bell, red, "Acesso do launcher", yn(listenerEnabled())) { openListenerSettings() }
            nav(rv, card, R.drawable.ic_bell, orange, "Notificações do sistema", null) {
                go(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            }
            info(rv, card, "As notificações são lidas apenas no telemóvel, nunca são enviadas para fora, e só são mostradas quando abres o painel.")
        }

        group("Controlos (permissões)") { rv, card ->
            nav(rv, card, R.drawable.ic_sun, blue, "Alterar brilho e rotação", yn(Settings.System.canWrite(this))) {
                go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            }
            nav(rv, card, R.drawable.ic_moon, purple, "Não incomodar", yn((getSystemService(android.app.NotificationManager::class.java)).isNotificationPolicyAccessGranted)) {
                go(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        }

        group("Controlo avançado") { rv, card ->
            nav(rv, card, R.drawable.ic_wifi, blue, "Ligar/desligar Wi-Fi, Bluetooth, voo e dados; bloquear; captura", yn(SystemActions.enabled())) {
                go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            info(rv, card, "Usa o serviço de Acessibilidade do Android: toca nos botões do painel de definições rápidas por ti. Em Definições › Acessibilidade › Apps instaladas, activa \"iPhone Experience\". Se aparecer \"Definição restrita\", segue o guia em \"Permissões e ajuda\". Só actua quando carregas num botão; não guarda nem envia nada.")
            nav(rv, card, R.drawable.ic_lock, 0xFF1C1C1E.toInt(), "Aplicar fundo ao ecrã de bloqueio real", null) {
                Wallpaper.applyToSystem(this, true, false) { ok ->
                    Toast.makeText(this, if (ok) "Fundo aplicado ao ecrã de bloqueio" else "Não foi possível aplicar", Toast.LENGTH_SHORT).show()
                }
            }
            nav(rv, card, R.drawable.ic_image, teal, "Aplicar fundo ao ecrã inicial do sistema", null) {
                Wallpaper.applyToSystem(this, false, true) { ok ->
                    Toast.makeText(this, if (ok) "Fundo aplicado" else "Não foi possível aplicar", Toast.LENGTH_SHORT).show()
                }
            }
            nav(rv, card, R.drawable.ic_close, red, "Repor ícones personalizados", null) {
                Icons.clearCustomAll(this); Toast.makeText(this, "Ícones repostos", Toast.LENGTH_SHORT).show()
            }
            info(rv, card, "Para pôr um ícone teu (ex.: um PNG): no ecrã inicial, toque longo numa app › Mudar ícone…")
        }

        group("Teclado") { rv, card ->
            nav(rv, card, R.drawable.ic_keyboard, gray, "Activar teclado iOS", null) { go(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
            nav(rv, card, R.drawable.ic_keyboard, blue, "Escolher teclado", null) {
                (getSystemService(InputMethodManager::class.java)).showInputMethodPicker()
            }
        }

        group("Ecrã de bloqueio iOS") { rv, card ->
            toggle(rv, card, R.drawable.ic_lock, 0xFF1C1C1E.toInt(), "Mostrar ao ligar o ecrã", prefs.lockSkin) { on ->
                prefs.lockSkin = on
                if (on && !Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Permite \"Sobrepor a outras apps\"", Toast.LENGTH_LONG).show()
                    go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else if (on && !listenerEnabled()) {
                    Toast.makeText(this, "Falta o acesso a notificações (é ele que detecta o ecrã a ligar)", Toast.LENGTH_LONG).show()
                }
            }
            toggle(rv, card, R.drawable.ic_bell, orange, "Mostrar texto das notificações com o telemóvel bloqueado", prefs.lockShowContent) { prefs.lockShowContent = it }
            nav(rv, card, R.drawable.ic_lock, 0xFF1C1C1E.toInt(), "Pré-visualizar", null) { startActivity(Intent(this, ClockActivity::class.java)) }
            info(rv, card, "É um ecrã por cima do bloqueio do Android: o PIN, padrão e impressão digital continuam a ser os do sistema e são pedidos quando deslizas para cima. Por privacidade, com o telemóvel bloqueado só aparece o nome da app, a não ser que ligues a opção acima. Ao ligar o ecrã pode aparecer por instantes o bloqueio original antes do iOS. Precisa de \"Sobrepor a outras apps\" e do acesso a notificações.")
        }

        group("Android (abre as definições reais)") { rv, card ->
            nav(rv, card, R.drawable.ic_wifi, blue, "Wi-Fi", null) { go(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            nav(rv, card, R.drawable.ic_bluetooth, blue, "Bluetooth", null) { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
            nav(rv, card, R.drawable.ic_signal, green, "Rede móvel", null) { go(Intent(Settings.ACTION_WIRELESS_SETTINGS)) }
            nav(rv, card, R.drawable.ic_sun, blue, "Ecrã e brilho", null) { go(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
            nav(rv, card, R.drawable.ic_speaker, red, "Som", null) { go(Intent(Settings.ACTION_SOUND_SETTINGS)) }
            nav(rv, card, R.drawable.ic_gear, gray, "Idioma do launcher", null) {
                go(Intent(Settings.ACTION_APP_LOCALE_SETTINGS, Uri.parse("package:$packageName")))
            }
            nav(rv, card, R.drawable.ic_gear, gray, "Idioma do sistema", null) { go(Intent(Settings.ACTION_LOCALE_SETTINGS)) }
            nav(rv, card, R.drawable.ic_gear, gray, "Definições do Android", null) { go(Intent(Settings.ACTION_SETTINGS)) }
        }

        val foot = tv("iPhone Experience 0.4.0 — launcher independente, não afiliado à Apple.", 12f, cSub)
        foot.gravity = Gravity.CENTER
        foot.setPadding(dpi(24), dpi(24), dpi(24), dpi(40))
        list.addView(foot)
        setContentView(sv)
    }

    private fun filter(q: String) {
        val n = q.trim().lowercase()
        for ((v, key) in rows) v.visibility = if (n.isEmpty() || key.contains(n)) View.VISIBLE else View.GONE
        for ((wrap, rvs) in groups) {
            wrap.visibility = if (n.isEmpty() || rvs.any { it.visibility == View.VISIBLE && rows.any { r -> r.first === it } }) View.VISIBLE else View.GONE
        }
    }

    private fun wallpaperDialog() {
        AlertDialog.Builder(this).setTitle("Papel de parede")
            .setItems(arrayOf("Estilo inicial (pêssego e petróleo)", "Estilo azul", "Escolher imagem da galeria")) { _, which ->
                when (which) {
                    0 -> { prefs.wallpaperMode = 0; build() }
                    1 -> { prefs.wallpaperMode = 1; build() }
                    else -> {
                        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
                        try { startActivityForResult(i, 77) } catch (e: Exception) { Toast.makeText(this, "Sem selector de imagens", Toast.LENGTH_SHORT).show() }
                    }
                }
            }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 77 && res == RESULT_OK) {
            val uri = data?.data
            if (uri != null && Wallpaper.importFrom(this, uri)) build()
            else Toast.makeText(this, "Não foi possível usar essa imagem", Toast.LENGTH_SHORT).show()
        }
    }
}
