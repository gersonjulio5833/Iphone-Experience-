package com.iphoneexperience.launcher

import android.app.Activity
import android.app.KeyguardManager
import android.app.Notification
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Rect
import android.os.BatteryManager
import android.os.Bundle
import android.provider.MediaStore
import android.service.notification.StatusBarNotification
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

/**
 * Ecrã de bloqueio ao estilo iOS, desenhado POR CIMA do ecrã de bloqueio seguro do Android.
 * Não o substitui nem o contorna: para abrir, o gesto de deslizar chama requestDismissKeyguard()
 * e o próprio Android pede o PIN / padrão / impressão digital. Com o telemóvel bloqueado, o
 * conteúdo das notificações fica escondido, salvo se o utilizador o permitir nas definições.
 */
class ClockActivity : Activity() {
    companion object { const val EXTRA_AUTO = "auto" }

    private var startX = 0f
    private var startY = 0f
    private var dragging = false
    private var auto = false
    private var busy = false
    private lateinit var root: FrameLayout
    private lateinit var list: LinearLayout
    private lateinit var listScroll: ScrollView
    private lateinit var torchBtn: FrameLayout
    private lateinit var km: KeyguardManager
    private lateinit var prefs: Prefs
    private val torchListener: (Boolean) -> Unit = { styleTorch(it) }
    private val changeListener: () -> Unit = { buildList() }
    private val mediaListener = object : MediaHub.Listener { override fun onMediaChanged() { buildList() } }
    private val unlockRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { if (auto) finishQuiet() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = Prefs.get(this)
        km = getSystemService(KeyguardManager::class.java)
        auto = intent.getBooleanExtra(EXTRA_AUTO, false)
        if (auto) { setShowWhenLocked(true); setTurnScreenOn(true) }
        Torch.init(this)
        window.setDecorFitsSystemWindows(false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.insetsController?.let {
            it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
            it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        val h = windowManager.currentWindowMetrics.bounds.height()
        val w = windowManager.currentWindowMetrics.bounds.width()

        root = FrameLayout(this)
        root.background = Wallpaper.make(this, true)

        val lockIcon = ImageView(this)
        lockIcon.setImageResource(R.drawable.ic_lock)
        lockIcon.setColorFilter(Color.WHITE)
        root.addView(lockIcon, FrameLayout.LayoutParams(dpi(20), dpi(20), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = (h * 0.075f).toInt() })

        val date = TextClock(this)
        date.format24Hour = "EEEE, d 'de' MMMM"
        date.format12Hour = "EEEE, d 'de' MMMM"
        date.setTextColor(0xE6FFFFFF.toInt())
        date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        date.typeface = Fonts.medium
        date.gravity = Gravity.CENTER
        root.addView(date, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP).apply { topMargin = (h * 0.115f).toInt() })

        val time = TextClock(this)
        time.format24Hour = "HH:mm"
        time.format12Hour = "h:mm"
        time.setTextColor(0xF2FFFFFF.toInt())
        time.setTextSize(TypedValue.COMPLEX_UNIT_PX, w * 0.27f)
        time.typeface = Fonts.displayBold
        time.includeFontPadding = false
        time.gravity = Gravity.CENTER
        time.letterSpacing = -0.02f
        root.addView(time, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP).apply { topMargin = (h * 0.115f).toInt() + dpi(26) })

        val battery = TextView(this)
        battery.setTextColor(Color.WHITE)
        battery.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        battery.typeface = Fonts.semibold
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        if (lvl >= 0) battery.text = (lvl * 100 / sc).toString() + "%"
        root.addView(battery, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).apply { topMargin = dpi(36); marginEnd = dpi(24) })

        // lista real: multimédia + notificações
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        listScroll = ScrollView(this)
        listScroll.isVerticalScrollBarEnabled = false
        listScroll.overScrollMode = View.OVER_SCROLL_NEVER
        listScroll.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(listScroll, FrameLayout.LayoutParams(MATCH, (h * 0.34f).toInt(), Gravity.TOP).apply {
            topMargin = (h * 0.44f).toInt(); leftMargin = dpi(14); rightMargin = dpi(14)
        })

        val d = dpi(54)
        torchBtn = FrameLayout(this)
        val ti = ImageView(this); ti.setImageResource(R.drawable.ic_flashlight); ti.setColorFilter(Color.WHITE)
        torchBtn.addView(ti, FrameLayout.LayoutParams(dpi(24), dpi(24), Gravity.CENTER))
        torchBtn.setOnClickListener { if (!Torch.toggle(this)) Toast.makeText(this, "Lanterna indisponível", Toast.LENGTH_SHORT).show() }
        root.addView(torchBtn, FrameLayout.LayoutParams(d, d, Gravity.BOTTOM or Gravity.START).apply { leftMargin = dpi(48); bottomMargin = dpi(64) })
        styleTorch(Torch.on)

        val cam = FrameLayout(this)
        cam.background = oval(0x59000000)
        val ci = ImageView(this); ci.setImageResource(R.drawable.ic_camera); ci.setColorFilter(Color.WHITE)
        cam.addView(ci, FrameLayout.LayoutParams(dpi(24), dpi(24), Gravity.CENTER))
        cam.setOnClickListener { openCamera() }
        root.addView(cam, FrameLayout.LayoutParams(d, d, Gravity.BOTTOM or Gravity.END).apply { rightMargin = dpi(48); bottomMargin = dpi(64) })

        val hint = TextView(this)
        hint.text = "Deslize para cima para abrir"
        hint.setTextColor(0xB3FFFFFF.toInt())
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        hint.typeface = Fonts.medium
        hint.gravity = Gravity.CENTER
        hint.setOnClickListener { unlock() }
        root.addView(hint, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { bottomMargin = dpi(34) })

        val bar = View(this)
        bar.background = rounded(Color.WHITE, dp(3f))
        root.addView(bar, FrameLayout.LayoutParams(dpi(134), dpi(5), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dpi(14) })

        setContentView(root)
        buildList()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun locked() = km.isKeyguardLocked
    private fun hideContent() = locked() && km.isDeviceSecure && !prefs.lockShowContent

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        c.setPadding(dpi(14), dpi(10), dpi(14), dpi(10))
        c.background = rounded(0x66202024, dp(20f))
        c.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dpi(8) }
        return c
    }

    private fun txt(t: String, sp: Float, color: Int, face: android.graphics.Typeface): TextView {
        val v = TextView(this)
        v.text = t; v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); v.setTextColor(color); v.typeface = face
        v.maxLines = 2; v.ellipsize = android.text.TextUtils.TruncateAt.END
        return v
    }

    private fun buildList() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        if (MediaHub.hasSession() && !MediaHub.title().isNullOrEmpty()) {
            val c = card()
            val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
            col.addView(txt(MediaHub.title() ?: "", 15f, Color.WHITE, Fonts.semibold))
            MediaHub.artist()?.let { col.addView(txt(it, 13f, 0xB3FFFFFF.toInt(), Fonts.regular)) }
            c.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            val pp = ImageView(this)
            pp.setImageResource(if (MediaHub.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play)
            pp.setColorFilter(Color.WHITE)
            pp.setPadding(dpi(8), dpi(8), dpi(8), dpi(8))
            pp.setOnClickListener { MediaHub.playPause() }
            c.addView(pp, LinearLayout.LayoutParams(dpi(44), dpi(44)))
            list.addView(c)
        }
        val hide = hideContent()
        val items = NotifListener.snapshot()
            .filter { it.packageName != packageName && it.isClearable && !it.isOngoing &&
                (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
            .sortedByDescending { it.postTime }
            .take(10)
        for (n in items) list.addView(notifCard(n, hide))
        if (NotifListener.instance == null && list.childCount == 0) {
            val c = card()
            c.addView(txt("Activa o acesso a notificações nas definições do launcher para veres aqui as tuas notificações.", 13f, 0xB3FFFFFF.toInt(), Fonts.regular))
            list.addView(c)
        }
    }

    private fun notifCard(n: StatusBarNotification, hide: Boolean): View {
        val c = card()
        val ic = ImageView(this)
        try { ic.setImageDrawable(packageManager.getApplicationIcon(n.packageName)) } catch (e: Exception) { }
        c.addView(ic, LinearLayout.LayoutParams(dpi(34), dpi(34)).apply { marginEnd = dpi(12) })
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        val ex = n.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        if (hide) {
            col.addView(txt(label(n.packageName), 15f, Color.WHITE, Fonts.semibold))
            col.addView(txt("Notificação", 13f, 0xB3FFFFFF.toInt(), Fonts.regular))
        } else {
            col.addView(txt(title ?: label(n.packageName), 15f, Color.WHITE, Fonts.semibold))
            if (!text.isNullOrEmpty()) col.addView(txt(text, 13f, 0xCCFFFFFF.toInt(), Fonts.regular))
        }
        c.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        c.setOnClickListener {
            val pi = n.notification.contentIntent
            requestUnlock { try { pi?.send() } catch (e: Exception) { } }
        }
        return c
    }

    private fun openCamera() {
        val action = if (locked()) MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE else MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA
        try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) {
            try { startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
            catch (e2: Exception) { Toast.makeText(this, "Câmara indisponível", Toast.LENGTH_SHORT).show() }
        }
    }

    /** Pede ao Android para desbloquear (PIN/padrão/biometria) e só depois executa [then]. */
    private fun requestUnlock(then: (() -> Unit)? = null) {
        if (busy) return
        if (!locked()) { then?.invoke(); finishQuiet(); return }
        busy = true
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { busy = false; then?.invoke(); finishQuiet() }
            override fun onDismissCancelled() { busy = false; snapBack() }
            override fun onDismissError() { busy = false; snapBack() }
        })
    }

    private fun unlock() {
        root.animate().translationY(-dpi(60).toFloat()).alpha(if (locked()) 1f else 0f).setDuration(220)
            .setInterpolator(SpringInterpolator(0.8f, 0.4f)).start()
        requestUnlock()
    }

    private fun snapBack() {
        root.animate().translationY(0f).alpha(1f).setDuration(380).setInterpolator(SpringInterpolator(0.7f, 0.45f)).start()
    }

    private fun finishQuiet() {
        if (isFinishing) return
        finish(); overridePendingTransition(0, android.R.anim.fade_out)
    }

    private fun styleTorch(on: Boolean) {
        torchBtn.background = oval(if (on) Color.WHITE else 0x59000000)
        (torchBtn.getChildAt(0) as ImageView).setColorFilter(if (on) Color.BLACK else Color.WHITE)
    }

    override fun onStart() {
        super.onStart()
        Torch.listeners.add(torchListener); styleTorch(Torch.on)
        NotifListener.changeListeners.add(changeListener)
        MediaHub.listeners.add(mediaListener)
        try { registerReceiver(unlockRx, IntentFilter(Intent.ACTION_USER_PRESENT)) } catch (e: Exception) { }
        buildList()
    }

    override fun onStop() {
        Torch.listeners.remove(torchListener)
        NotifListener.changeListeners.remove(changeListener)
        MediaHub.listeners.remove(mediaListener)
        try { unregisterReceiver(unlockRx) } catch (e: Exception) { }
        // fora do ecrã (ex.: ecrã desligou): em modo automático fecha, para não ficar uma activity à toa
        if (auto && !isChangingConfigurations) finish()
        super.onStop()
    }

    private fun insideScrollableList(x: Float, y: Float): Boolean {
        val r = Rect()
        listScroll.getGlobalVisibleRect(r)
        return r.contains(x.toInt(), y.toInt()) &&
            (listScroll.canScrollVertically(1) || listScroll.canScrollVertically(-1))
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                startX = ev.rawX; startY = ev.rawY; dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dy = startY - ev.rawY
                if (!dragging && dy > dpi(18) && dy > Math.abs(startX - ev.rawX) && !insideScrollableList(startX, startY)) {
                    dragging = true
                    val cancel = MotionEvent.obtain(ev); cancel.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(cancel); cancel.recycle()
                }
                if (dragging) {
                    val d = Math.max(0f, dy)
                    root.translationY = -d
                    root.alpha = (1f - d / (root.height * 0.9f)).coerceIn(0.3f, 1f)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                dragging = false
                if (startY - ev.rawY > dpi(110) && ev.actionMasked == MotionEvent.ACTION_UP) unlock() else snapBack()
                return true
            }
        }
        return if (dragging) true else super.dispatchTouchEvent(ev)
    }
}
