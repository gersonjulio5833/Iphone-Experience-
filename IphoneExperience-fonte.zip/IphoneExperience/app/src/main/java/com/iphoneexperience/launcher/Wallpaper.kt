package com.iphoneexperience.launcher

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import java.io.File

/**
 * Papéis de parede desenhados em código (sem imagens do iOS):
 * estilo 0 = composição "inicial" (pêssego/rosa + onda azul-petróleo),
 * estilo 1 = composição "bloqueio" (azul-céu + onda azul-escura + fita clara).
 */
interface Shiftable { var shift: Float; var dim: Float }

class VectorWallpaper(private val style: Int) : Drawable(), Shiftable {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override var shift = 0f
        set(v) { if (field != v) { field = v; invalidateSelf() } }
    override var dim = 0f

    private fun vg(h: Float, y0: Float, y1: Float, colors: IntArray, pos: FloatArray?): LinearGradient =
        LinearGradient(0f, y0 * h, 0f, y1 * h, colors, pos, Shader.TileMode.CLAMP)

    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        if (w <= 0f || h <= 0f) return
        c.save()
        c.translate(bounds.left.toFloat(), bounds.top.toFloat())
        c.scale(1.1f, 1.1f, w / 2f, h / 2f)
        c.translate(shift, 0f)
        if (style == 1) drawBlue(c, w, h) else drawBloom(c, w, h)
        c.restore()
        if (dim > 0f) {
            p.shader = null
            p.color = Color.argb((255 * dim).toInt(), 0, 0, 0)
            c.drawRect(bounds, p)
        }
    }

    private fun drawBloom(c: Canvas, w: Float, h: Float) {
        p.shader = vg(h, 0f, 1f, intArrayOf(0xFFF8D8B4.toInt(), 0xFFF6A3A6.toInt(), 0xFFF3B6B2.toInt()),
            floatArrayOf(0f, 0.38f, 1f))
        c.drawRect(0f, 0f, w, h, p)
        p.shader = RadialGradient(w * 0.88f, h * 0.02f, w * 0.95f,
            intArrayOf(0xFFFBE9A8.toInt(), 0x00FBE9A8), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)

        val blue = Path().apply {
            moveTo(w, h * 0.27f)
            cubicTo(w * 0.62f, h * 0.38f, w * 0.50f, h * 0.55f, w * 0.36f, h * 0.72f)
            cubicTo(w * 0.22f, h * 0.88f, w * 0.08f, h * 0.96f, 0f, h * 0.98f)
            lineTo(0f, h); lineTo(w, h); close()
        }
        p.shader = vg(h, 0.25f, 1f, intArrayOf(0xFF1AA6BE.toInt(), 0xFF0B6A98.toInt(), 0xFF08335F.toInt(), 0xFF062447.toInt()),
            floatArrayOf(0f, 0.35f, 0.8f, 1f))
        c.drawPath(blue, p)

        val dx = w * 0.07f
        val band = Path().apply {
            moveTo(w, h * 0.27f)
            cubicTo(w * 0.62f, h * 0.38f, w * 0.50f, h * 0.55f, w * 0.36f, h * 0.72f)
            cubicTo(w * 0.22f, h * 0.88f, w * 0.08f, h * 0.96f, 0f, h * 0.98f)
            lineTo(dx, h * 0.98f)
            cubicTo(w * 0.08f + dx, h * 0.96f, w * 0.22f + dx, h * 0.88f, w * 0.36f + dx, h * 0.72f)
            cubicTo(w * 0.50f + dx, h * 0.55f, w * 0.62f + dx, h * 0.38f, w + dx, h * 0.27f)
            close()
        }
        p.shader = null
        p.color = 0x40C9CBD8
        c.drawPath(band, p)
    }

    private fun drawBlue(c: Canvas, w: Float, h: Float) {
        p.shader = vg(h, 0f, 1f, intArrayOf(0xFF9BDCFF.toInt(), 0xFF4FB2EE.toInt(), 0xFFE8C6C2.toInt()),
            floatArrayOf(0f, 0.45f, 1f))
        c.drawRect(0f, 0f, w, h, p)

        val navy = Path().apply {
            moveTo(w, h * 0.18f)
            cubicTo(w * 0.62f, h * 0.28f, w * 0.52f, h * 0.36f, w * 0.52f, h * 0.48f)
            cubicTo(w * 0.52f, h * 0.62f, w * 0.40f, h * 0.76f, w * 0.04f, h * 0.97f)
            lineTo(0f, h); lineTo(w, h); close()
        }
        p.shader = vg(h, 0.18f, 1f, intArrayOf(0xFF1A78E0.toInt(), 0xFF0B4DB0.toInt(), 0xFF03123F.toInt(), 0xFF010624.toInt()),
            floatArrayOf(0f, 0.35f, 0.75f, 1f))
        c.drawPath(navy, p)

        val ribbon = Path().apply {
            moveTo(w * 0.52f, h * 0.405f)
            cubicTo(w * 0.52f, h * 0.60f, w * 0.40f, h * 0.74f, w * 0.04f, h * 0.97f)
            cubicTo(w * 0.20f, h * 0.80f, w * 0.30f, h * 0.66f, w * 0.46f, h * 0.45f)
            close()
        }
        p.shader = vg(h, 0.40f, 0.97f, intArrayOf(0xF2F4F6FB.toInt(), 0xCCC9D2E6.toInt(), 0x66E8C6C2.toInt()), null)
        c.drawPath(ribbon, p)

        val upper = Path().apply {
            moveTo(w, h * 0.34f)
            cubicTo(w * 0.80f, h * 0.40f, w * 0.60f, h * 0.44f, w * 0.52f, h * 0.45f)
            lineTo(w * 0.52f, h * 0.40f)
            cubicTo(w * 0.70f, h * 0.34f, w * 0.90f, h * 0.30f, w, h * 0.29f)
            close()
        }
        p.shader = null
        p.color = 0x4066A8E8
        c.drawPath(upper, p)
    }

    override fun setAlpha(a: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

class CropImageDrawable(private val bmp: Bitmap) : Drawable(), Shiftable {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    override var shift = 0f
        set(v) { if (field != v) { field = v; invalidateSelf() } }
    override var dim = 0f
    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat(); val h = bounds.height().toFloat()
        if (w <= 0f || h <= 0f) return
        val s = maxOf(w / bmp.width, h / bmp.height) * 1.1f
        val m = Matrix()
        m.postScale(s, s)
        m.postTranslate((w - bmp.width * s) / 2f + bounds.left + shift, (h - bmp.height * s) / 2f + bounds.top)
        c.save(); c.clipRect(bounds); c.drawBitmap(bmp, m, paint)
        if (dim > 0f) { c.drawColor(Color.argb((255 * dim).toInt(), 0, 0, 0)) }
        c.restore()
    }
    override fun setAlpha(a: Int) { paint.alpha = a }
    override fun setColorFilter(cf: ColorFilter?) { paint.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

object Wallpaper {
    /** Aplica o fundo (mesmo desenho do ecrã de relógio) ao ecrã de bloqueio e/ou inicial REAIS do Android. */
    fun applyToSystem(ctx: Context, lock: Boolean, home: Boolean, cb: (Boolean) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            val ok = try {
                val b = app.getSystemService(android.view.WindowManager::class.java).currentWindowMetrics.bounds
                val bmp = Bitmap.createBitmap(b.width(), b.height(), Bitmap.Config.ARGB_8888)
                val d = make(app, lock)
                d.setBounds(0, 0, b.width(), b.height())
                d.draw(Canvas(bmp))
                var flags = 0
                if (lock) flags = flags or android.app.WallpaperManager.FLAG_LOCK
                if (home) flags = flags or android.app.WallpaperManager.FLAG_SYSTEM
                android.app.WallpaperManager.getInstance(app).setBitmap(bmp, null, true, flags)
                true
            } catch (e: Exception) { false }
            android.os.Handler(android.os.Looper.getMainLooper()).post { cb(ok) }
        }.start()
    }

    fun file(ctx: Context) = File(ctx.filesDir, "wallpaper.jpg")

    fun make(ctx: Context, forLock: Boolean): Drawable {
        val p = Prefs.get(ctx)
        if (p.wallpaperMode == 2) {
            val f = file(ctx)
            if (f.exists()) decode(f.absolutePath, 2200)?.let { return CropImageDrawable(it) }
        }
        return VectorWallpaper(if (forLock) 1 else p.wallpaperMode.coerceIn(0, 1))
    }

    private fun decode(path: String, maxDim: Int): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / s > maxDim || o.outHeight / s > maxDim) s *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
    } catch (e: Exception) { null }

    /** Copia a imagem escolhida pelo utilizador para o armazenamento interno da app. */
    fun importFrom(ctx: Context, uri: android.net.Uri): Boolean = try {
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            file(ctx).outputStream().use { out -> ins.copyTo(out) }
        }
        Prefs.get(ctx).wallpaperMode = 2
        true
    } catch (e: Exception) { false }
}
