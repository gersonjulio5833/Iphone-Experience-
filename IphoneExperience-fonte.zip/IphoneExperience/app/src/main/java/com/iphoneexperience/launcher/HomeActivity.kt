package com.iphoneexperience.launcher

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.app.SearchManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.DragEvent
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.animation.LinearInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.Normalizer
import java.util.concurrent.Executors

class Origin(val kind: Int, val a: Int, val b: Int) {
    companion object { const val PAGE = 0; const val DOCK = 1 }
}

class MenuRow(val label: String, val danger: Boolean, val action: () -> Unit)

/** Ecrã inicial: Hoje | páginas de apps | Biblioteca, dock, pastas, pesquisa, modo de edição e gestos. */
class HomeActivity : Activity() {
    lateinit var prefs: Prefs
    lateinit var widgets: WidgetHelper
    private var pendingIconApp: AppInfo? = null
    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private var pager: PagerView? = null
    private var dotsRow: LinearLayout? = null
    private var dockBar: LinearLayout? = null

    private var model = HomeModel()
    var apps: Map<String, AppInfo> = emptyMap()
    var insetTop = 0
    var insetBottom = 0
    var sw = 0
    var sh = 0
    private var cellW = 0
    private var pitch = 0
    private var iconPx = 0
    private var pagerTop = 0
    private var dockLeft = 0
    private var dockTop = 0
    private var dockW = 0
    private var dockH = 0
    private var uiKey = ""
    private var todayOffset = 0
    private var savedPage = 0
    private var startedOnce = false
    private var launched = false
    private var editing = false
    private var okBtn: View? = null

    private var dragSrc: Origin? = null
    private var edgeDir = 0
    private val ui = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()

    private var cc: ControlCenter? = null
    private var notif: NotifPanel? = null
    private var searchView: View? = null
    private var searchField: EditText? = null
    private var folderView: View? = null
    private var ctxMenu: View? = null
    private var pullView: View? = null
    private var pullKind = 0
    private var pulling = false

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { loadApps() }
    }

    // ------------------------------------------------------------------ ciclo de vida

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = Prefs.get(this)
        widgets = WidgetHelper(this)
        Torch.init(this)
        window.setDecorFitsSystemWindows(false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.isNavigationBarContrastEnforced = false

        val b = windowManager.currentWindowMetrics.bounds
        sw = b.width(); sh = b.height()

        root = FrameLayout(this)
        applyWallpaper()
        content = FrameLayout(this)
        root.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        root.setOnApplyWindowInsetsListener { _, ins ->
            val bars = ins.getInsets(WindowInsets.Type.systemBars())
            if (bars.top != insetTop || bars.bottom != insetBottom || pager == null) {
                insetTop = bars.top; insetBottom = bars.bottom
                buildUi()
            }
            ins
        }
        root.setOnDragListener { _, e -> onDrag(e) }

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, f)
        applyBars()
        loadApps()
    }

    private fun applyWallpaper() {
        val d = Wallpaper.make(this, false)
        (d as? Shiftable)?.dim = if (prefs.isDark(this)) 0.28f else 0f
        root.background = d
    }

    override fun onStart() {
        super.onStart()
        widgets.start()
    }

    override fun onStop() {
        widgets.stop()
        super.onStop()
    }

    fun isEditing(): Boolean = editing
    fun refreshAll() { renderAll() }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (widgets.onResult(req, res, data)) { renderAll(); return }
        if (req == 4201) {
            val app = pendingIconApp
            val uri = data?.data
            pendingIconApp = null
            if (res == RESULT_OK && app != null && uri != null) {
                if (Icons.importCustom(this, app.pkg, uri)) renderAll()
                else Toast.makeText(this, "Não foi possível usar essa imagem", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun pickIcon(app: AppInfo) {
        pendingIconApp = app
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
        try { startActivityForResult(i, 4201) } catch (e: Exception) {
            pendingIconApp = null
            Toast.makeText(this, "Sem selector de imagens", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        val key = currentUiKey()
        if (pager != null) {
            if (key != uiKey) {
                applyWallpaper(); applyBars()
                if (apps.isNotEmpty()) model = HomeModel.load(prefs, apps, this)
                buildUi()
            } else {
                Icons.clearDynamic()
                renderAll()
            }
        }
        cc?.refresh()
        if (launched) { launched = false; playReturn() }
    }

    private fun playReturn() {
        if (!prefs.animations) return
        content.alpha = 0.25f
        content.scaleX = 1.14f; content.scaleY = 1.14f
        content.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(520).setInterpolator(SPRING_SOFT).start()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) goHome()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { goHome() }

    private fun goHome() {
        when {
            editing -> exitEdit()
            overlayOpen() -> closeAllOverlays()
            else -> pager?.snapTo(todayOffset)
        }
    }

    private fun currentUiKey() =
        "${prefs.iconScale}|${prefs.glass}|${prefs.showLabels}|${prefs.showSearch}|${prefs.theme}|${prefs.wallpaperMode}|" +
            "${prefs.iconStyle}|${prefs.todayPage}|${prefs.libraryPage}|${prefs.hiddenCsv.hashCode()}|${Wallpaper.file(this).lastModified()}"

    private fun applyBars() {
        val light = prefs.wallpaperMode == 0 && !prefs.isDark(this)
        window.insetsController?.setSystemBarsAppearance(
            if (light) WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS else 0,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
        )
    }

    // ------------------------------------------------------------------ dados

    private fun loadApps() {
        exec.execute {
            val list = AppRepo.loadAll(this)
            runOnUiThread {
                apps = list.associateBy { it.id }
                model = HomeModel.load(prefs, apps, this)
                if (pager != null) renderAll()
            }
        }
    }

    fun appList(): Collection<AppInfo> = apps.values

    // ------------------------------------------------------------------ construção da UI

    private fun iconTop(h: Int, labels: Boolean) = ((h - iconPx - (if (labels) dpi(18) else 0)) / 2).coerceAtLeast(0)

    private fun buildUi() {
        uiKey = currentUiKey()
        content.removeAllViews()
        cellW = sw / 4
        iconPx = (sw * 0.152f * prefs.iconScale / 100f).toInt()
        dockH = dpi(92)
        dockW = sw - dpi(24)
        dockLeft = (sw - dockW) / 2
        val dockBottom = insetBottom + dpi(8)
        dockTop = sh - dockBottom - dockH
        val pillH = dpi(34)
        val dotsH = dpi(18)
        val reserved = dockBottom + dockH + dpi(12) + (if (prefs.showSearch) pillH + dpi(8) else 0) + dotsH
        pagerTop = insetTop + dpi(10)
        val avail = sh - pagerTop - reserved
        pitch = minOf((sw * 0.255f).toInt(), avail / 6)

        val pg = PagerView(this)
        pg.onPageChanged = { savedPage = pg.current; updateDots() }
        pg.onScrolled = { x ->
            if (prefs.parallax) {
                val total = (pg.pageCount - 1).coerceAtLeast(1) * sw
                (root.background as? Shiftable)?.shift = (0.5f - x.toFloat() / total) * 2f * sw * 0.045f
            }
        }
        pager = pg
        content.addView(pg, FrameLayout.LayoutParams(MATCH, pitch * 6).apply { topMargin = pagerTop })

        val dr = LinearLayout(this)
        dr.orientation = LinearLayout.HORIZONTAL
        dr.gravity = Gravity.CENTER
        dotsRow = dr
        val dotsBottom = dockBottom + dockH + dpi(12) + (if (prefs.showSearch) pillH + dpi(8) else 0)
        content.addView(dr, FrameLayout.LayoutParams(WRAP, dotsH).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; bottomMargin = dotsBottom
        })

        if (prefs.showSearch) {
            val pill = TextView(this)
            pill.text = "  Pesquisar"
            pill.setTextColor(Color.WHITE)
            pill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            pill.typeface = Fonts.medium
            pill.gravity = Gravity.CENTER
            pill.setPadding(dpi(18), 0, dpi(18), 0)
            pill.background = rounded(Color.argb(80, 0, 0, 0), dp(17f))
            val ic = getDrawable(R.drawable.ic_search)!!.mutate()
            ic.setTint(Color.WHITE)
            ic.setBounds(0, 0, dpi(14), dpi(14))
            pill.setCompoundDrawables(ic, null, null, null)
            pill.setOnClickListener { showSearch() }
            pill.pressScale(prefs.animations)
            content.addView(pill, FrameLayout.LayoutParams(WRAP, pillH).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = dockBottom + dockH + dpi(12)
            })
        }

        val dock = LinearLayout(this)
        dock.orientation = LinearLayout.HORIZONTAL
        dock.gravity = Gravity.CENTER
        dock.background = rounded(glassLight(prefs), dp(34f))
        dockBar = dock
        content.addView(dock, FrameLayout.LayoutParams(dockW, dockH).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; bottomMargin = dockBottom
        })

        if (editing) addOkButton()
        if (apps.isNotEmpty()) renderAll()
    }

    private fun renderAll() {
        val pg = pager ?: return
        val dock = dockBar ?: return
        todayOffset = if (prefs.todayPage) 1 else 0
        val want = if (!startedOnce) todayOffset else savedPage
        startedOnce = true

        val views = mutableListOf<View>()
        if (prefs.todayPage) views.add(TodayView(this))
        for ((pi, items) in model.pages.withIndex()) {
            val page = FrameLayout(this)
            page.setOnLongClickListener { if (!editing) { enterEdit(); true } else false }
            for ((i, item) in items.withIndex()) {
                val o = Origin(Origin.PAGE, pi, i)
                val v: View? = when (item) {
                    is Item.App -> apps[item.id]?.let { appCell(it, o, cellW, pitch, prefs.showLabels) { v -> launch(it, v) } }
                    is Item.Folder -> folderCell(item, o, cellW, pitch)
                }
                if (v != null) page.addView(v, FrameLayout.LayoutParams(cellW, pitch).apply {
                    leftMargin = (i % 4) * cellW; topMargin = (i / 4) * pitch
                })
            }
            views.add(page)
        }
        if (prefs.libraryPage && apps.isNotEmpty()) views.add(LibraryView(this))
        pg.setPages(views)
        pg.snapTo(want, false)

        dock.removeAllViews()
        val slotW = dockW / 4
        for ((si, id) in model.dock.withIndex()) {
            val app = apps[id] ?: continue
            dock.addView(appCell(app, Origin(Origin.DOCK, si, 0), slotW, dockH, false) { v -> launch(app, v) },
                LinearLayout.LayoutParams(slotW, dockH))
        }
        updateDots()
    }

    private fun updateDots() {
        val dr = dotsRow ?: return
        val pg = pager ?: return
        dr.removeAllViews()
        if (pg.pageCount < 2) return
        for (i in 0 until pg.pageCount) {
            val d = View(this)
            d.background = oval(if (i == pg.current) Color.WHITE else 0x66FFFFFF)
            dr.addView(d, LinearLayout.LayoutParams(dpi(7), dpi(7)).apply { marginStart = dpi(4); marginEnd = dpi(4) })
        }
    }

    private fun label(text: String, w: Int): TextView = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        gravity = Gravity.CENTER
        setShadowLayer(dp(2f), 0f, dp(1f), 0x66000000)
        layoutParams = LinearLayout.LayoutParams(w, WRAP).apply { topMargin = dpi(5) }
    }

    private fun appCell(app: AppInfo, origin: Origin?, w: Int, h: Int, labels: Boolean, onTap: (View) -> Unit): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(0, iconTop(h, labels), 0, 0)
        val iv = ImageView(this)
        iv.tag = app.id
        col.addView(iv, LinearLayout.LayoutParams(iconPx, iconPx))
        Icons.load(this, app, iconPx) { b -> if (iv.tag == app.id) iv.setImageBitmap(b) }
        if (labels) col.addView(label(app.label, w - dpi(6)))
        col.setOnClickListener { if (!editing) onTap(iv) }
        col.pressScale(prefs.animations)
        return decorate(col, origin, w, h, labels, Item.App(app.id))
    }

    private fun folderCell(f: Item.Folder, origin: Origin?, w: Int, h: Int): View {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(0, iconTop(h, true), 0, 0)
        val iv = ImageView(this)
        iv.tag = f
        col.addView(iv, LinearLayout.LayoutParams(iconPx, iconPx))
        Icons.folder(this, f.ids.mapNotNull { apps[it] }, iconPx) { b -> if (iv.tag === f) iv.setImageBitmap(b) }
        col.addView(label(f.name, w - dpi(6)))
        col.setOnClickListener { if (!editing) openFolder(f, false) }
        col.pressScale(prefs.animations)
        return decorate(col, origin, w, h, true, f)
    }

    /** Menu de contexto (toque longo) ou, no modo de edição, bamboleio + emblema × + arrastar. */
    private fun decorate(col: View, origin: Origin?, w: Int, h: Int, labels: Boolean, item: Item): View {
        if (origin == null) return col
        if (!editing) {
            col.setOnLongClickListener { showItemContextMenu(col, origin); true }
            return col
        }
        val wrap = FrameLayout(this)
        wrap.addView(col, FrameLayout.LayoutParams(w, h))
        val bs = dpi(22)
        val badge = FrameLayout(this)
        badge.background = oval(0xFFC7C7CC.toInt())
        val x = ImageView(this)
        x.setImageResource(R.drawable.ic_close)
        x.setColorFilter(0xFF3A3A3C.toInt())
        badge.addView(x, FrameLayout.LayoutParams(dpi(13), dpi(13), Gravity.CENTER))
        badge.setOnClickListener {
            when (item) {
                is Item.App -> hideApp(item.id)
                is Item.Folder -> dissolveFolder(item)
            }
        }
        wrap.addView(badge, FrameLayout.LayoutParams(bs, bs).apply {
            leftMargin = ((w - iconPx) / 2 - dpi(7)).coerceAtLeast(0)
            topMargin = (iconTop(h, labels) - dpi(7)).coerceAtLeast(0)
        })
        // arrastar após pequeno movimento
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var dx = 0f; var dy = 0f
        col.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.hypot((e.rawX - dx).toDouble(), (e.rawY - dy).toDouble()) > slop && dragSrc == null) startDrag(wrap, origin)
                }
            }
            true
        }
        if (prefs.animations) {
            val rnd = (Math.random() * 60).toLong()
            val a = ObjectAnimator.ofFloat(wrap, "rotation", -1.6f, 1.6f)
            a.duration = 120 + rnd
            a.repeatCount = ObjectAnimator.INFINITE
            a.repeatMode = ObjectAnimator.REVERSE
            a.interpolator = LinearInterpolator()
            a.startDelay = rnd
            a.start()
        }
        return wrap
    }

    // ------------------------------------------------------------------ modo de edição

    private fun addOkButton() {
        okBtn?.let { content.removeView(it) }
        val t = TextView(this)
        t.text = "OK"
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        t.typeface = Fonts.medium
        t.gravity = Gravity.CENTER
        t.setPadding(dpi(16), 0, dpi(16), 0)
        t.background = rounded(0x66000000, dp(16f))
        t.setOnClickListener { exitEdit() }
        content.addView(t, FrameLayout.LayoutParams(WRAP, dpi(32)).apply {
            gravity = Gravity.TOP or Gravity.END; topMargin = insetTop + dpi(6); marginEnd = dpi(16)
        })
        okBtn = t
    }

    private fun enterEdit() {
        closeMenu()
        if (editing) return
        editing = true
        addOkButton()
        renderAll()
    }

    private fun exitEdit() {
        editing = false
        okBtn?.let { content.removeView(it) }
        okBtn = null
        model.normalize(); model.save(prefs)
        renderAll()
    }

    fun hideApp(id: String) {
        val h = prefs.hidden()
        h.add(id)
        prefs.setHidden(h)
        model = HomeModel.load(prefs, apps, this)
        uiKey = currentUiKey()
        renderAll()
        Toast.makeText(this, "Ocultada do ecrã inicial. Continua na Biblioteca de Apps.", Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ lançar apps

    fun launch(app: AppInfo, from: View?) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.pkg, app.cls))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            launched = true
            if (from != null && prefs.animations) {
                val o = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
                startActivity(i, o.toBundle())
            } else startActivity(i)
        } catch (e: Exception) {
            launched = false
            Toast.makeText(this, "Não foi possível abrir ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ arrastar e largar

    private fun startDrag(v: View, o: Origin): Boolean {
        dragSrc = o
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val ok = v.startDragAndDrop(ClipData.newPlainText("item", "item"), View.DragShadowBuilder(v), null, 0)
        if (ok) v.alpha = 0.25f else dragSrc = null
        return ok
    }

    private fun onDrag(e: DragEvent): Boolean {
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> return dragSrc != null
            DragEvent.ACTION_DRAG_LOCATION -> handleEdge(e.x)
            DragEvent.ACTION_DROP -> { cancelEdge(); handleDrop(e.x, e.y) }
            DragEvent.ACTION_DRAG_ENDED -> { cancelEdge(); dragSrc = null; model.normalize(); renderAll() }
        }
        return true
    }

    private val edgeRunnable = object : Runnable {
        override fun run() {
            val pg = pager ?: return
            if (edgeDir == 0) return
            val target = pg.current + edgeDir
            val mi = target - todayOffset
            if (mi >= 0) {
                if (mi >= model.pages.size && model.pages.lastOrNull()?.isNotEmpty() == true && mi == model.pages.size) {
                    model.pages.add(mutableListOf())
                    renderAll()
                }
                if (mi < model.pages.size) pg.snapTo(target)
            }
            ui.postDelayed(this, 900)
        }
    }

    private fun handleEdge(x: Float) {
        val d = if (x < dpi(28)) -1 else if (x > sw - dpi(28)) 1 else 0
        if (d != edgeDir) {
            ui.removeCallbacks(edgeRunnable)
            edgeDir = d
            if (d != 0) ui.postDelayed(edgeRunnable, 650)
        }
    }

    private fun cancelEdge() { ui.removeCallbacks(edgeRunnable); edgeDir = 0 }

    private fun itemOf(o: Origin): Item? = when (o.kind) {
        Origin.PAGE -> model.pages.getOrNull(o.a)?.getOrNull(o.b)
        else -> model.dock.getOrNull(o.a)?.let { Item.App(it) }
    }

    private fun removeSrc(o: Origin, item: Item) {
        if (o.kind == Origin.PAGE) {
            model.pages.getOrNull(o.a)?.let { l ->
                val i = l.indexOfFirst { it === item }
                if (i >= 0) l.removeAt(i)
            }
        } else if (o.a in model.dock.indices) model.dock.removeAt(o.a)
    }

    private fun handleDrop(x: Float, y: Float) {
        val o = dragSrc ?: return
        dragSrc = null
        val item = itemOf(o) ?: return
        var changed = false
        if (y >= dockTop - dpi(10)) changed = dockDrop(x, o, item)
        else if (y >= pagerTop && y <= pagerTop + pitch * 6) changed = pageDrop(x, y, o, item)
        if (changed) {
            model.normalize()
            model.save(prefs)
        }
    }

    private fun dockDrop(x: Float, o: Origin, item: Item): Boolean {
        val app = item as? Item.App
        if (app == null) { Toast.makeText(this, "As pastas não podem ir para o dock", Toast.LENGTH_SHORT).show(); return false }
        val slotW = dockW / 4f
        val n = model.dock.size
        val start = dockLeft + (dockW - n * slotW) / 2f
        val slot = ((x - start) / slotW).toInt().coerceIn(0, n)
        if (o.kind == Origin.DOCK) {
            if (slot == o.a || slot == o.a + 1) return false
            val id = model.dock.removeAt(o.a)
            model.dock.add(slot.coerceIn(0, model.dock.size), id)
            return true
        }
        if (model.dock.size >= 4) {
            val t = slot.coerceIn(0, model.dock.size - 1)
            val displaced = model.dock[t]
            model.dock[t] = app.id
            val list = model.pages.getOrNull(o.a) ?: return true
            val idx = list.indexOfFirst { it === item }
            if (idx >= 0) list[idx] = Item.App(displaced)
        } else {
            removeSrc(o, item)
            model.dock.add(slot.coerceIn(0, model.dock.size), app.id)
        }
        return true
    }

    private fun pageDrop(x: Float, y: Float, o: Origin, item: Item): Boolean {
        val pg = pager ?: return false
        val pageIdx = pg.current - todayOffset
        if (pageIdx !in model.pages.indices) return false
        val list = model.pages[pageIdx]
        val col = (x / cellW).toInt().coerceIn(0, 3)
        val row = ((y - pagerTop) / pitch).toInt().coerceIn(0, 5)
        val idx = row * 4 + col
        if (idx < list.size) {
            val target = list[idx]
            if (target === item) return false
            val cx = col * cellW + cellW / 2f
            val cy = pagerTop + row * pitch + pitch / 2f
            val near = Math.abs(x - cx) < cellW * 0.30f && Math.abs(y - cy) < pitch * 0.32f
            if (near && item is Item.App) {
                if (target is Item.Folder) {
                    removeSrc(o, item)
                    target.ids.add(item.id)
                    return true
                }
                if (target is Item.App && target.id != item.id) {
                    removeSrc(o, item)
                    val ti = list.indexOfFirst { it === target }
                    if (ti >= 0) list[ti] = Item.Folder("Pasta", mutableListOf(target.id, item.id))
                    return true
                }
            }
        }
        removeSrc(o, item)
        list.add(idx.coerceIn(0, list.size), item)
        return true
    }

    // ------------------------------------------------------------------ menus e pastas

    private fun showItemContextMenu(anchor: View, o: Origin) {
        val item = itemOf(o) ?: return
        val rows = mutableListOf<MenuRow>()
        when (item) {
            is Item.App -> {
                val app = apps[item.id] ?: return
                rows.add(MenuRow("Editar ecrã inicial", false) { enterEdit() })
                rows.add(MenuRow("Informações da app", false) {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg)))
                })
                rows.add(MenuRow("Mudar ícone…", false) { pickIcon(app) })
                if (Icons.hasCustom(this, app.pkg)) rows.add(MenuRow("Repor ícone", false) { Icons.removeCustom(this, app.pkg); renderAll() })
                rows.add(MenuRow("Ocultar do ecrã inicial", false) { hideApp(app.id) })
                rows.add(MenuRow("Desinstalar", true) {
                    try { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg))) }
                    catch (e: Exception) { Toast.makeText(this, "Não foi possível desinstalar", Toast.LENGTH_SHORT).show() }
                })
            }
            is Item.Folder -> {
                rows.add(MenuRow("Mudar nome", false) { renameFolder(item) })
                rows.add(MenuRow("Editar ecrã inicial", false) { enterEdit() })
                rows.add(MenuRow("Desfazer pasta", true) { dissolveFolder(item) })
            }
        }
        showMenu(anchor, rows)
    }

    private fun showMenu(anchor: View, rows: List<MenuRow>) {
        if (ctxMenu != null) return
        anchor.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val ov = FrameLayout(this)
        ov.setBackgroundColor(0x22000000)
        ov.setOnClickListener { closeMenu() }
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = rounded(0xEB2C2C2E.toInt(), dp(16f))
        card.isClickable = true
        for ((i, r) in rows.withIndex()) {
            val t = TextView(this)
            t.text = r.label
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            t.setTextColor(if (r.danger) 0xFFFF453A.toInt() else Color.WHITE)
            t.setPadding(dpi(16), 0, dpi(16), 0)
            t.gravity = Gravity.CENTER_VERTICAL
            t.setOnClickListener { closeMenu(); r.action() }
            card.addView(t, LinearLayout.LayoutParams(MATCH, dpi(48)))
            if (i < rows.size - 1) {
                val sep = View(this); sep.setBackgroundColor(0x33FFFFFF)
                card.addView(sep, LinearLayout.LayoutParams(MATCH, 1))
            }
        }
        val loc = IntArray(2)
        anchor.getLocationInWindow(loc)
        val cw = dpi(240)
        val chh = rows.size * dpi(48)
        val x = (loc[0] + anchor.width / 2 - cw / 2).coerceIn(dpi(12), sw - cw - dpi(12))
        var y = loc[1] + anchor.height + dpi(6)
        val above = y + chh > sh - insetBottom - dpi(8)
        if (above) y = (loc[1] - chh - dpi(6)).coerceAtLeast(insetTop + dpi(8))
        ov.addView(card, FrameLayout.LayoutParams(cw, WRAP).apply { leftMargin = x; topMargin = y })
        ctxMenu = ov
        root.addView(ov, FrameLayout.LayoutParams(MATCH, MATCH))
        updateBlur()
        if (prefs.animations) {
            card.pivotX = cw / 2f; card.pivotY = if (above) chh.toFloat() else 0f
            card.scaleX = 0.5f; card.scaleY = 0.5f; card.alpha = 0f
            card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(380).setInterpolator(SPRING).start()
        }
    }

    private fun closeMenu() {
        val v = ctxMenu ?: return
        ctxMenu = null
        root.removeView(v)
        updateBlur()
    }

    private fun renameFolder(f: Item.Folder) {
        val et = EditText(this)
        et.setText(f.name)
        AlertDialog.Builder(this).setTitle("Nome da pasta").setView(et)
            .setPositiveButton("OK") { _, _ ->
                f.name = et.text.toString().ifBlank { "Pasta" }
                model.save(prefs); renderAll()
            }.setNegativeButton("Cancelar", null).show()
    }

    private fun dissolveFolder(f: Item.Folder) {
        for (page in model.pages) {
            val i = page.indexOfFirst { it === f }
            if (i >= 0) {
                page.removeAt(i)
                page.addAll(i, f.ids.map { Item.App(it) })
                break
            }
        }
        model.normalize(); model.save(prefs); renderAll()
    }

    fun openCategory(title: String, ids: List<String>) {
        openFolder(Item.Folder(title, ids.toMutableList()), true)
    }

    private fun openFolder(f: Item.Folder, readOnly: Boolean) {
        if (folderView != null) return
        val ov = FrameLayout(this)
        ov.setBackgroundColor(Color.argb(90, 0, 0, 0))
        ov.setOnClickListener { closeFolder(readOnly) }

        val cardW = (sw * 0.88f).toInt()
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dpi(12), dpi(16), dpi(12), dpi(16))
        card.background = rounded(Color.argb(200, 70, 72, 82), dp(36f))
        card.isClickable = true

        val title = EditText(this)
        title.setText(f.name)
        title.setTextColor(Color.WHITE)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        title.typeface = Fonts.medium
        title.gravity = Gravity.CENTER
        title.background = null
        title.isEnabled = !readOnly
        title.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        title.imeOptions = EditorInfo.IME_ACTION_DONE
        title.setSingleLine()
        title.setOnEditorActionListener { v, _, _ ->
            f.name = v.text.toString().ifBlank { "Pasta" }
            model.save(prefs)
            (getSystemService(InputMethodManager::class.java)).hideSoftInputFromWindow(v.windowToken, 0)
            true
        }
        card.addView(title, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dpi(8) })

        val cw = (cardW - dpi(24)) / 3
        val ch = pitch
        val sv = ScrollView(this)
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        sv.addView(grid, FrameLayout.LayoutParams(MATCH, WRAP))
        for (rowIds in f.ids.chunked(3)) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for (id in rowIds) {
                val app = apps[id] ?: continue
                val cell = appCell(app, null, cw, ch, true) { v -> closeFolder(readOnly); launch(app, v) }
                if (!readOnly) cell.setOnLongClickListener {
                    AlertDialog.Builder(this).setTitle(app.label)
                        .setItems(arrayOf("Tirar da pasta", "Informações da app")) { _, which ->
                            if (which == 0) {
                                f.ids.remove(id)
                                for (page in model.pages) {
                                    val i = page.indexOfFirst { it === f }
                                    if (i >= 0) { page.add(i + 1, Item.App(id)); break }
                                }
                                closeFolder(false)
                            } else startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg)))
                        }.show()
                    true
                }
                r.addView(cell, LinearLayout.LayoutParams(cw, ch))
            }
            grid.addView(r)
        }
        card.addView(sv, LinearLayout.LayoutParams(MATCH, minOf(ch * 3, sh / 2)))
        ov.addView(card, FrameLayout.LayoutParams(cardW, WRAP, Gravity.CENTER))
        folderView = ov
        root.addView(ov, FrameLayout.LayoutParams(MATCH, MATCH))
        updateBlur()
        if (prefs.animations) {
            card.scaleX = 0.6f; card.scaleY = 0.6f; ov.alpha = 0f
            ov.animate().alpha(1f).setDuration(200).start()
            card.animate().scaleX(1f).scaleY(1f).setDuration(460).setInterpolator(SPRING).start()
        }
    }

    private fun closeFolder(readOnly: Boolean = false) {
        val v = folderView ?: return
        folderView = null
        root.removeView(v)
        if (!readOnly) { model.normalize(); model.save(prefs) }
        updateBlur()
        if (!readOnly) renderAll()
    }

    // ------------------------------------------------------------------ pesquisa

    private fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase()

    fun showSearch() {
        if (overlayOpen()) return
        val ov = FrameLayout(this)
        ov.setBackgroundColor(Color.argb(120, 0, 0, 0))
        ov.setOnClickListener { closeSearch() }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dpi(16), insetTop + dpi(16), dpi(16), 0)

        val field = EditText(this)
        field.hint = "Pesquisar"
        field.setHintTextColor(0x99FFFFFF.toInt())
        field.setTextColor(Color.WHITE)
        field.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        field.setSingleLine()
        field.imeOptions = EditorInfo.IME_ACTION_SEARCH
        field.background = rounded(Color.argb(110, 90, 90, 96), dp(14f))
        field.setPadding(dpi(14), dpi(10), dpi(14), dpi(10))
        val ic = getDrawable(R.drawable.ic_search)!!.mutate()
        ic.setTint(0xB3FFFFFF.toInt())
        ic.setBounds(0, 0, dpi(18), dpi(18))
        field.setCompoundDrawables(ic, null, null, null)
        field.compoundDrawablePadding = dpi(8)
        col.addView(field, LinearLayout.LayoutParams(MATCH, WRAP))

        val results = LinearLayout(this)
        results.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.addView(results, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(sv, LinearLayout.LayoutParams(MATCH, (sh * 0.40f).toInt()).apply { topMargin = dpi(10) })
        ov.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        fun row(app: AppInfo): View {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(dpi(6), dpi(7), dpi(6), dpi(7))
            val iv = ImageView(this)
            iv.tag = app.id
            r.addView(iv, LinearLayout.LayoutParams(dpi(44), dpi(44)))
            Icons.load(this, app, dpi(44)) { b -> if (iv.tag == app.id) iv.setImageBitmap(b) }
            val t = TextView(this)
            t.text = app.label
            t.setTextColor(Color.WHITE)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            r.addView(t, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dpi(14) })
            r.setOnClickListener { closeSearch(); launch(app, iv) }
            return r
        }

        fun fill(q: String) {
            results.removeAllViews()
            val n = norm(q.trim())
            if (n.isEmpty()) return
            apps.values.filter { norm(it.label).contains(n) }.take(12).forEach { results.addView(row(it)) }
            val web = TextView(this)
            web.text = "Pesquisar na Web: " + q.trim()
            web.setTextColor(0xFF64B5FF.toInt())
            web.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            web.setPadding(dpi(6), dpi(14), dpi(6), dpi(14))
            web.setOnClickListener {
                closeSearch()
                try { startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q.trim()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q.trim())))) }
            }
            results.addView(web)
        }
        field.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { fill(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        field.setOnEditorActionListener { _, _, _ ->
            val first = apps.values.firstOrNull { norm(it.label).contains(norm(field.text.toString().trim())) && field.text.isNotBlank() }
            if (first != null) { closeSearch(); launch(first, null) }
            true
        }
        searchView = ov
        searchField = field
        root.addView(ov, FrameLayout.LayoutParams(MATCH, MATCH))
        updateBlur()
        if (prefs.animations) { ov.alpha = 0f; ov.animate().alpha(1f).setDuration(180).start() }
        field.requestFocus()
        field.postDelayed({ getSystemService(InputMethodManager::class.java).showSoftInput(field, 0) }, 150)
    }

    private fun closeSearch() {
        val v = searchView ?: return
        searchField?.let { getSystemService(InputMethodManager::class.java).hideSoftInputFromWindow(it.windowToken, 0) }
        searchView = null; searchField = null
        root.removeView(v)
        updateBlur()
    }

    // ------------------------------------------------------------------ painéis (controlo / notificações)

    fun overlayOpen(): Boolean =
        cc != null || notif != null || searchView != null || folderView != null || ctxMenu != null || pullView != null

    fun closeAllOverlays() {
        closeMenu(); closeSearch(); closeFolder(false); closeControlCenter(); closeNotifications()
    }

    fun updateBlur() {
        val any = overlayOpen()
        content.setRenderEffect(if (any) RenderEffect.createBlurEffect(26f, 26f, Shader.TileMode.CLAMP) else null)
    }

    private fun slideIn(v: View) {
        v.translationY = -sh.toFloat()
        if (prefs.animations) v.animate().translationY(0f).setDuration(520).setInterpolator(SPRING_SOFT).start()
        else v.translationY = 0f
    }

    private fun slideOut(v: View) {
        if (prefs.animations) {
            v.animate().translationY(-sh.toFloat()).setDuration(320).setInterpolator(SPRING_SOFT)
                .withEndAction { root.removeView(v); updateBlur() }.start()
        } else { root.removeView(v); updateBlur() }
    }

    fun showControlCenter() {
        if (overlayOpen()) return
        val v = ControlCenter(this)
        cc = v
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        updateBlur()
        slideIn(v)
    }

    fun closeControlCenter() {
        val v = cc ?: return
        cc = null
        slideOut(v)
    }

    fun showNotifications() {
        if (overlayOpen()) return
        val v = NotifPanel(this)
        notif = v
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        updateBlur()
        slideIn(v)
    }

    fun closeNotifications() {
        val v = notif ?: return
        notif = null
        slideOut(v)
    }

    // puxar painéis a seguir o dedo
    private fun beginPull(kind: Int) {
        val v: View = if (kind == 1) NotifPanel(this) else ControlCenter(this)
        pullKind = kind
        pullView = v
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        v.translationY = -sh.toFloat()
        updateBlur()
    }

    private fun movePull(dy: Float) {
        pullView?.translationY = (-sh + dy).coerceIn(-sh.toFloat(), 0f)
    }

    private fun endPull(dy: Float) {
        val v = pullView ?: return
        pullView = null
        if (dy > sh * 0.22f) {
            if (pullKind == 1) notif = v as NotifPanel else cc = v as ControlCenter
            v.animate().translationY(0f).setDuration(480).setInterpolator(SPRING_SOFT).start()
            updateBlur()
        } else {
            v.animate().translationY(-sh.toFloat()).setDuration(260).setInterpolator(SPRING_SOFT)
                .withEndAction { root.removeView(v); updateBlur() }.start()
        }
    }

    // ------------------------------------------------------------------ gestos

    private var gx = 0f
    private var gy = 0f
    private var gTracking = false
    private var gFired = false

    private fun onHomePage(): Boolean {
        val pg = pager ?: return false
        return pg.current - todayOffset in model.pages.indices
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (pulling) {
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE -> movePull(ev.rawY - gy)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { endPull(ev.rawY - gy); pulling = false }
            }
            return true
        }
        if (overlayOpen() || editing) return super.dispatchTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { gx = ev.rawX; gy = ev.rawY; gTracking = true; gFired = false }
            MotionEvent.ACTION_MOVE -> if (gTracking && !gFired && dragSrc == null) {
                val dy = ev.rawY - gy
                val dx = ev.rawX - gx
                if (dy > dpi(60) && dy > Math.abs(dx) * 1.6f && onHomePage()) {
                    gFired = true
                    gTracking = false
                    val c = MotionEvent.obtain(ev)
                    c.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(c)
                    c.recycle()
                    if (gy < sh * 0.22f) {
                        beginPull(if (gx < sw * 0.5f) 1 else 2)
                        pulling = true
                        movePull(dy)
                    } else showSearch()
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> gTracking = false
        }
        if (gFired && ev.actionMasked != MotionEvent.ACTION_DOWN) return true
        return super.dispatchTouchEvent(ev)
    }
}
