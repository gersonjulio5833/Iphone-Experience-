package com.iphoneexperience.launcher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Serviço de Acessibilidade (opcional, activado pelo utilizador). Usos, todos a pedido:
 *  - ligar/desligar Wi-Fi, Bluetooth, modo de voo e dados móveis: abre o painel de definições rápidas do Android,
 *    carrega no botão correspondente (como tu farias) e fecha o painel;
 *  - bloquear o ecrã (bloqueio real do Android) e tirar captura de ecrã.
 * Não regista eventos, não guarda nem envia nada.
 */
class SystemActions : AccessibilityService() {
    companion object {
        var instance: SystemActions? = null
        fun enabled(): Boolean = instance != null

        val WIFI = listOf("wi-fi", "wifi")
        val WIFI_AVOID = listOf("zona", "hotspot", "partilh")
        val BT = listOf("bluetooth")
        val AIR = listOf("modo de avião", "modo de voo", "modo avião", "airplane", "flight mode")
        val DATA = listOf("dados móveis", "dados de telemóvel", "mobile data", "dados móveis")
    }

    private val h = Handler(Looper.getMainLooper())
    private var cover: View? = null

    override fun onServiceConnected() {
        instance = this
        super.onServiceConnected()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        hideCover()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }

    fun lockScreen(): Boolean = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    fun screenshot(): Boolean = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)

    fun toggleTile(keys: List<String>, avoid: List<String>, onDone: (Boolean) -> Unit) {
        showCover()
        if (!performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)) {
            hideCover(); onDone(false); return
        }
        attempt(keys, avoid, 0, onDone)
    }

    private fun attempt(keys: List<String>, avoid: List<String>, n: Int, onDone: (Boolean) -> Unit) {
        h.postDelayed({
            val node = findTile(keys, avoid)
            if (node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                h.postDelayed({
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    h.postDelayed({ hideCover(); onDone(true) }, 250)
                }, 450)
            } else if (n < 10) {
                attempt(keys, avoid, n + 1, onDone)
            } else {
                performGlobalAction(GLOBAL_ACTION_BACK)
                h.postDelayed({ hideCover(); onDone(false) }, 250)
            }
        }, if (n == 0) 650L else 250L)
    }

    private fun findTile(keys: List<String>, avoid: List<String>): AccessibilityNodeInfo? {
        val ws = try { windows } catch (e: Exception) { return null }
        for (w in ws) {
            val r = w.root ?: continue
            val f = search(r, keys, avoid, 0)
            if (f != null) return f
        }
        return null
    }

    private fun search(n: AccessibilityNodeInfo, keys: List<String>, avoid: List<String>, depth: Int): AccessibilityNodeInfo? {
        if (depth > 30) return null
        if (n.isClickable && n.isVisibleToUser) {
            val t = ((n.contentDescription?.toString() ?: "") + " " + (n.text?.toString() ?: "")).lowercase()
            if (keys.any { t.contains(it) } && !avoid.any { t.contains(it) }) return n
        }
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val r = search(c, keys, avoid, depth + 1)
            if (r != null) return r
        }
        return null
    }

    /** Cobre o ecrã durante a operação para o painel não "piscar". */
    private fun showCover() {
        if (cover != null) return
        val v = View(this)
        v.setBackgroundColor(0xF2000000.toInt())
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        try { getSystemService(WindowManager::class.java).addView(v, lp); cover = v } catch (e: Exception) { cover = null }
        h.postDelayed({ hideCover() }, 6000)
    }

    private fun hideCover() {
        val v = cover ?: return
        cover = null
        try { getSystemService(WindowManager::class.java).removeView(v) } catch (e: Exception) { }
    }
}
