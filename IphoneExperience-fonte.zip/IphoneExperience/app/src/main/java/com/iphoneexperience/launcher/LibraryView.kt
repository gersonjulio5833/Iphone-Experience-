package com.iphoneexperience.launcher

import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Biblioteca de apps: categorias automáticas (ApplicationInfo.category) + lista A–Z. */
class LibraryView(private val a: HomeActivity) : FrameLayout(a) {
    private val prefs = Prefs.get(a)

    private fun category(app: AppInfo): String {
        val cat = try { a.packageManager.getApplicationInfo(app.pkg, 0).category } catch (e: Exception) { ApplicationInfo.CATEGORY_UNDEFINED }
        return when (cat) {
            ApplicationInfo.CATEGORY_SOCIAL -> "Social"
            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> "Entretenimento"
            ApplicationInfo.CATEGORY_IMAGE -> "Criatividade"
            ApplicationInfo.CATEGORY_GAME -> "Jogos"
            ApplicationInfo.CATEGORY_PRODUCTIVITY, ApplicationInfo.CATEGORY_NEWS -> "Produtividade e notícias"
            ApplicationInfo.CATEGORY_MAPS -> "Viagens e mapas"
            else -> "Utilidades"
        }
    }

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(a.dpi(14), 0, a.dpi(14), a.dpi(24))
        sv.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))

        val search = TextView(a)
        search.text = "  Biblioteca de Apps"
        search.setTextColor(0xE6FFFFFF.toInt())
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        search.gravity = Gravity.CENTER_VERTICAL
        search.setPadding(a.dpi(14), 0, a.dpi(14), 0)
        search.background = rounded(0x55000000, a.dp(14f))
        val ic = a.getDrawable(R.drawable.ic_search)!!.mutate()
        ic.setTint(0xCCFFFFFF.toInt()); ic.setBounds(0, 0, a.dpi(18), a.dpi(18))
        search.setCompoundDrawables(ic, null, null, null)
        search.setOnClickListener { a.showSearch() }
        col.addView(search, LinearLayout.LayoutParams(MATCH, a.dpi(44)).apply { bottomMargin = a.dpi(12) })

        val groups = a.appList().groupBy { category(it) }.toSortedMap()
        val cardW = (a.sw - a.dpi(28) - a.dpi(12)) / 2
        val keys = groups.keys.toList()
        var i = 0
        while (i < keys.size) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            for (j in 0..1) {
                if (i + j >= keys.size) break
                val k = keys[i + j]
                row.addView(categoryCard(k, groups[k]!!.sortedBy { it.label.lowercase() }, cardW),
                    LinearLayout.LayoutParams(cardW, WRAP).apply { if (j == 1) marginStart = a.dpi(12) })
            }
            col.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = a.dpi(12) })
            i += 2
        }

        val h = TextView(a)
        h.text = "Todas as apps"
        h.setTextColor(Color.WHITE); h.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        h.typeface = Fonts.bold
        h.setPadding(a.dpi(4), a.dpi(8), 0, a.dpi(6))
        col.addView(h)
        val list = LinearLayout(a)
        list.orientation = LinearLayout.VERTICAL
        list.background = rounded(glassDark(prefs), a.dp(22f))
        list.setPadding(a.dpi(10), a.dpi(6), a.dpi(10), a.dpi(6))
        var last = ' '
        for (app in a.appList().sortedBy { it.label.lowercase() }) {
            val ch = app.label.firstOrNull()?.uppercaseChar() ?: '#'
            if (ch != last) {
                last = ch
                val l = TextView(a)
                l.text = ch.toString()
                l.setTextColor(0x99FFFFFF.toInt()); l.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                l.setPadding(a.dpi(6), a.dpi(10), 0, a.dpi(2))
                list.addView(l)
            }
            val r = LinearLayout(a)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            r.setPadding(a.dpi(4), a.dpi(6), a.dpi(4), a.dpi(6))
            val iv = ImageView(a); iv.tag = app.id
            r.addView(iv, LinearLayout.LayoutParams(a.dpi(40), a.dpi(40)))
            Icons.load(a, app, a.dpi(40)) { b -> if (iv.tag == app.id) iv.setImageBitmap(b) }
            val t = TextView(a)
            t.text = app.label; t.setTextColor(Color.WHITE); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            r.addView(t, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = a.dpi(12) })
            r.setOnClickListener { a.launch(app, iv) }
            list.addView(r)
        }
        col.addView(list, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun categoryCard(name: String, apps: List<AppInfo>, w: Int): View {
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        val card = FrameLayout(a)
        card.background = rounded(glassDark(prefs), a.dp(24f))
        val pad = a.dpi(10)
        val ic = (w - 3 * pad) / 2
        for (slot in 0 until 4) {
            val app = apps.getOrNull(slot) ?: continue
            val x = pad + (slot % 2) * (ic + pad)
            val y = pad + (slot / 2) * (ic + pad)
            val iv = ImageView(a); iv.tag = app.id
            Icons.load(a, app, ic) { b -> if (iv.tag == app.id) iv.setImageBitmap(b) }
            iv.setOnClickListener { a.launch(app, iv) }
            iv.pressScale(prefs.animations)
            if (slot == 3 && apps.size > 4) {
                // quarto lugar: mini-grelha com as restantes
                val g = FrameLayout(a)
                val mini = (ic - a.dpi(6)) / 2
                for (k in 0 until minOf(4, apps.size - 3)) {
                    val ap = apps[3 + k]
                    val v = ImageView(a); v.tag = ap.id
                    Icons.load(a, ap, mini) { b -> if (v.tag == ap.id) v.setImageBitmap(b) }
                    g.addView(v, FrameLayout.LayoutParams(mini, mini).apply { leftMargin = (k % 2) * (mini + a.dpi(2)); topMargin = (k / 2) * (mini + a.dpi(2)) })
                }
                g.setOnClickListener { a.openCategory(name, apps.map { it.id }) }
                card.addView(g, FrameLayout.LayoutParams(ic, ic).apply { leftMargin = x; topMargin = y })
            } else {
                card.addView(iv, FrameLayout.LayoutParams(ic, ic).apply { leftMargin = x; topMargin = y })
            }
        }
        val h = pad * 3 + ic * 2
        box.addView(card, LinearLayout.LayoutParams(w, h))
        val t = TextView(a)
        t.text = name
        t.setTextColor(Color.WHITE); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.setShadowLayer(a.dp(2f), 0f, a.dp(1f), 0x66000000)
        box.addView(t, LinearLayout.LayoutParams(w, WRAP).apply { topMargin = a.dpi(4) })
        card.setOnClickListener { a.openCategory(name, apps.map { it.id }) }
        return box
    }
}
