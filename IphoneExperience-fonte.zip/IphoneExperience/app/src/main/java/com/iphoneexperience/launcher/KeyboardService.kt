package com.iphoneexperience.launcher

import android.graphics.Color
import android.graphics.Typeface
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView

/**
 * Teclado opcional inspirado no iOS (português). Letras, maiúsculas (toque duplo = fixar),
 * números/símbolos, acentos por pressão longa, balão de pré-visualização da tecla, espaço duplo = ponto,
 * apagar com repetição, painel de emojis, sugestões (dicionário local + palavras que escreves).
 * Tudo local: nada é enviado para fora; em campos de palavra-passe não aprende nem sugere.
 */
class KeyboardService : InputMethodService() {
    private val ui = Handler(Looper.getMainLooper())
    private var dark = false
    private var mode = 0              // 0 letras, 1 números, 2 símbolos, 3 emojis
    private var shift = 1             // 0 minúsculas, 1 uma vez, 2 bloqueado
    private var word = StringBuilder()
    private var secret = false
    private var lastShiftTap = 0L
    private var lastSpaceTap = 0L
    private var preview: PopupWindow? = null
    private lateinit var root: LinearLayout
    private lateinit var sugg: LinearLayout
    private lateinit var rowsBox: LinearLayout

    private val letters = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val nums = listOf("1234567890", "-/:;()€&@\"", ".,?!'")
    private val syms = listOf("[]{}#%^*+=", "_\\|~<>$£¥•", ".,?!'")
    private val accents = mapOf(
        'a' to "áàâãä", 'e' to "éèêë", 'i' to "íìîï", 'o' to "óòôõö", 'u' to "úùûü",
        'c' to "ç", 'n' to "ñ"
    )
    private val emojis = ("😀😃😄😁😆😅😂🤣😊😇🙂😉😍🥰😘😋😎🤩🥳😏😒😞😔😟😕🙁😣😖😫😩🥺😢😭😤😠😡🤯😳🥵🥶😱😨😰😥😓🤗🤔🤭🤫😶😐😑😬🙄😯😴🤤😪😵🤐🥴🤢🤮😷🤒🤕" +
        "👍👎👌✌️🤞🤟🤘👈👉👆👇👋🤚✋🖖👏🙌🤝🙏💪❤️🧡💛💚💙💜🖤💔💕💞💓💗💖🔥✨⭐🌟💫🎉🎊🎁🏆⚽🏀🎵🎶🎤🎧📱💻📷🚗✈️🏠🌍🌞🌙☀️⛅🌧️🌈🍕🍔🍟🍎🍌🍇🍺☕").let { s ->
        val out = mutableListOf<String>()
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            var j = i + Character.charCount(cp)
            // junta selectores de variação
            while (j < s.length && (s[j] == '️' || s[j] == '‍')) j++
            out.add(s.substring(i, j)); i = j
        }
        out
    }
    private val dict = listOf(
        "olá", "obrigado", "obrigada", "bom", "boa", "dia", "tarde", "noite", "sim", "não", "como", "estás", "está",
        "tudo", "bem", "para", "porque", "quando", "onde", "quem", "que", "com", "sem", "mais", "menos", "muito",
        "pouco", "hoje", "amanhã", "ontem", "agora", "depois", "antes", "aqui", "ali", "ainda", "também", "mas",
        "por", "favor", "desculpa", "claro", "certo", "casa", "trabalho", "amigo", "amiga", "telemóvel", "mensagem",
        "chamada", "vamos", "vou", "estou", "podes", "posso", "preciso", "quero", "gosto", "tenho", "temos",
        "fazer", "ver", "falar", "saber", "ir", "vir", "ser", "estar", "ter", "dar", "nada", "alguém", "semana",
        "fim", "tempo", "dinheiro", "família", "vida", "mundo", "parabéns", "saudades", "beijinho", "abraço"
    )

    private fun learned(): MutableSet<String> =
        Prefs.get(this).sp.getStringSet("learned", emptySet())!!.toMutableSet()

    override fun onCreateInputView(): View {
        dark = Prefs.get(this).isDark(this)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(if (dark) 0xFF1B1B1D.toInt() else 0xFFD1D3D9.toInt())
        root.setPadding(dpi(3), dpi(2), dpi(3), dpi(6))
        sugg = LinearLayout(this)
        sugg.orientation = LinearLayout.HORIZONTAL
        sugg.gravity = Gravity.CENTER
        root.addView(sugg, LinearLayout.LayoutParams(MATCH, dpi(40)))
        rowsBox = LinearLayout(this)
        rowsBox.orientation = LinearLayout.VERTICAL
        root.addView(rowsBox, LinearLayout.LayoutParams(MATCH, WRAP))
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        word.setLength(0)
        mode = 0
        val type = info?.inputType ?: 0
        val variation = type and InputType.TYPE_MASK_VARIATION
        secret = (type and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT &&
            (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD) ||
            (type and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER &&
            (variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        val cap = currentInputConnection?.getCursorCapsMode(type) ?: 0
        shift = if (cap != 0) 1 else 0
        if (::root.isInitialized) render()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        hidePreview()
        super.onFinishInputView(finishingInput)
    }

    // ---------------------------------------------------------------- desenho

    private fun keyBg(special: Boolean, pressed: Boolean = false, active: Boolean = false) = rounded(
        when {
            pressed -> if (dark) 0xFF5A5A5E.toInt() else 0xFFAEB3BE.toInt()
            active -> if (dark) 0xFFEFEFEF.toInt() else Color.WHITE
            special -> if (dark) 0xFF3A3A3C.toInt() else 0xFFABB1BB.toInt()
            else -> if (dark) 0xFF6A6A6C.toInt() else Color.WHITE
        }, dp(5f)
    )

    private fun showPreview(v: View, label: String) {
        hidePreview()
        val t = TextView(this)
        t.text = label
        t.gravity = Gravity.CENTER
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32f)
        t.setTextColor(if (dark) Color.WHITE else Color.BLACK)
        t.background = rounded(if (dark) 0xFF6A6A6C.toInt() else Color.WHITE, dp(10f))
        t.elevation = dp(6f)
        val w = maxOf(v.width + dpi(14), dpi(56))
        val h = dpi(64)
        val pw = PopupWindow(t, w, h, false)
        pw.isTouchable = false
        pw.isClippingEnabled = false
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        try {
            pw.showAtLocation(root, Gravity.NO_GRAVITY, loc[0] + v.width / 2 - w / 2, loc[1] - h - dpi(4))
            preview = pw
        } catch (e: Exception) { preview = null }
    }

    private fun hidePreview() {
        try { preview?.dismiss() } catch (e: Exception) { }
        preview = null
    }

    private fun key(
        label: String?, icon: Int?, weight: Float, special: Boolean,
        onTap: () -> Unit, onLong: (() -> Unit)? = null, repeat: Boolean = false, active: Boolean = false
    ): View {
        val f = FrameLayout(this)
        f.background = keyBg(special, false, active)
        val txtColor = if (active) Color.BLACK else if (dark) Color.WHITE else Color.BLACK
        if (icon != null) {
            val iv = ImageView(this); iv.setImageResource(icon); iv.setColorFilter(txtColor)
            f.addView(iv, FrameLayout.LayoutParams(dpi(22), dpi(22), Gravity.CENTER))
        } else {
            val t = TextView(this)
            t.text = label; t.setTextColor(txtColor)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, if ((label?.length ?: 0) > 1) 15f else 22f)
            t.gravity = Gravity.CENTER
            f.addView(t, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        var rep: Runnable? = null
        var longFired = false
        val showBubble = !special && label != null && label.length == 1 && mode != 3
        f.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.background = keyBg(special, true, active)
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    longFired = false
                    if (showBubble && onLong == null) showPreview(v, label!!)
                    if (repeat) {
                        onTap()
                        rep = object : Runnable { override fun run() { onTap(); ui.postDelayed(this, 55) } }
                        ui.postDelayed(rep!!, 400)
                    } else if (onLong != null) {
                        if (showBubble) showPreview(v, label!!)
                        rep = Runnable { longFired = true; hidePreview(); onLong() }
                        ui.postDelayed(rep!!, 380)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.background = keyBg(special, false, active)
                    rep?.let { ui.removeCallbacks(it) }
                    hidePreview()
                    if (!repeat && !longFired) onTap()
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.background = keyBg(special, false, active)
                    rep?.let { ui.removeCallbacks(it) }
                    hidePreview()
                }
            }
            true
        }
        f.layoutParams = LinearLayout.LayoutParams(0, MATCH, weight).apply { setMargins(dpi(3), dpi(4), dpi(3), dpi(4)) }
        return f
    }

    private fun row(vararg views: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in views) r.addView(v)
        r.layoutParams = LinearLayout.LayoutParams(MATCH, dpi(50))
        return r
    }

    private fun render() {
        hidePreview()
        rowsBox.removeAllViews()
        if (mode == 3) { renderEmoji(); updateSuggestions(); return }
        val src = when (mode) { 1 -> nums; 2 -> syms; else -> letters }
        for ((ri, chars) in src.withIndex()) {
            val views = mutableListOf<View>()
            if (ri == 2) {
                if (mode == 0) views.add(key(null, R.drawable.ic_shift, 1.5f, true, { cycleShift() }, null, false, shift != 0))
                else views.add(key(if (mode == 1) "#+=" else "123", null, 1.5f, true, { mode = if (mode == 1) 2 else 1; render() }))
            }
            for (ch in chars) views.add(charKey(ch))
            if (ri == 2) views.add(key(null, R.drawable.ic_backspace, 1.5f, true, { del() }, null, true))
            if (ri == 1 && mode == 0) { views.add(0, spacer(0.5f)); views.add(spacer(0.5f)) }
            rowsBox.addView(row(*views.toTypedArray()))
        }
        rowsBox.addView(bottomRow(false))
        updateSuggestions()
    }

    private fun bottomRow(emoji: Boolean): View = row(
        key(if (emoji || mode != 0) "ABC" else "123", null, 1.3f, true, {
            mode = if (emoji || mode != 0) 0 else 1; render()
        }),
        key(null, if (emoji) R.drawable.ic_keyboard else R.drawable.ic_emoji, 1.0f, true, {
            mode = if (emoji) 0 else 3; render()
        }, { switchToNextInputMethod(false) }),
        key("espaço", null, 4.2f, false, { space() }),
        key(enterLabel(), null, 1.6f, true, { enter() })
    )

    private fun renderEmoji() {
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val g = GridLayout(this)
        g.columnCount = 8
        val cell = (resources.displayMetrics.widthPixels - dpi(6)) / 8
        for (e in emojis) {
            val t = TextView(this)
            t.text = e
            t.gravity = Gravity.CENTER
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            t.setOnClickListener { commit(e); endWord() }
            g.addView(t, GridLayout.LayoutParams().apply { width = cell; height = dpi(46) })
        }
        sv.addView(g)
        rowsBox.addView(sv, LinearLayout.LayoutParams(MATCH, dpi(150)))
        val br = row(
            key("ABC", null, 1.5f, true, { mode = 0; render() }),
            key("espaço", null, 4.2f, false, { space() }),
            key(null, R.drawable.ic_backspace, 1.5f, true, { del() }, null, true)
        )
        rowsBox.addView(br)
    }

    private fun spacer(w: Float): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, MATCH, w) }

    private fun charKey(ch: Char): View {
        val shown = if (mode == 0 && shift != 0) ch.uppercaseChar() else ch
        val alts = if (mode == 0) accents[ch] else null
        return key(shown.toString(), null, 1f, false, { typeChar(shown) }, if (alts != null) { { showAccents(alts, shown) } } else null)
    }

    private fun enterLabel(): String = when ((currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION) {
        EditorInfo.IME_ACTION_SEARCH -> "pesquisar"
        EditorInfo.IME_ACTION_SEND -> "enviar"
        EditorInfo.IME_ACTION_GO -> "ir"
        EditorInfo.IME_ACTION_DONE -> "ok"
        EditorInfo.IME_ACTION_NEXT -> "seguinte"
        else -> "↵"
    }

    // ---------------------------------------------------------------- acções

    private fun commit(s: String) { currentInputConnection?.commitText(s, 1) }

    private fun typeChar(c: Char) {
        commit(c.toString())
        if (c.isLetter() || c == '\'' || c == '-') word.append(c) else endWord()
        if (mode == 0 && shift == 1) { shift = 0; render() } else updateSuggestions()
    }

    private fun learn() {
        if (secret) return
        val w = word.toString().lowercase()
        if (w.length < 3 || !w.all { it.isLetter() || it == '\'' || it == '-' }) return
        if (dict.contains(w)) return
        val set = learned()
        if (set.size > 600) return
        if (set.add(w)) Prefs.get(this).sp.edit().putStringSet("learned", set).apply()
    }

    private fun endWord() { learn(); word.setLength(0); updateSuggestions() }

    private fun space() {
        val ic = currentInputConnection ?: return
        val now = System.currentTimeMillis()
        val before = ic.getTextBeforeCursor(2, 0)?.toString() ?: ""
        if (now - lastSpaceTap < 450 && before.length == 2 && before[1] == ' ' && before[0].isLetterOrDigit()) {
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
            lastSpaceTap = 0
            word.setLength(0)
            if (mode == 0) { shift = 1; render() } else updateSuggestions()
            return
        }
        lastSpaceTap = now
        commit(" ")
        endWord()
    }

    private fun cycleShift() {
        val now = System.currentTimeMillis()
        shift = when {
            shift == 2 -> 0
            now - lastShiftTap < 350 -> 2
            shift == 1 -> 0
            else -> 1
        }
        lastShiftTap = now
        render()
    }

    private fun del() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) ic.commitText("", 1) else ic.deleteSurroundingText(1, 0)
        if (word.isNotEmpty()) word.setLength(word.length - 1)
        updateSuggestions()
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        val action = (currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnter = ((currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED && !noEnter) ic.performEditorAction(action)
        else commit("\n")
        endWord()
    }

    private fun showAccents(alts: String, base: Char) {
        sugg.removeAllViews()
        val all = base.toString() + alts
        for (c in all) {
            val s = if (mode == 0 && shift != 0) c.uppercaseChar() else c
            val t = TextView(this)
            t.text = s.toString()
            t.setTextColor(if (dark) Color.WHITE else Color.BLACK)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            t.gravity = Gravity.CENTER
            t.setOnClickListener { typeChar(s) }
            sugg.addView(t, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
    }

    private fun updateSuggestions() {
        if (!::sugg.isInitialized) return
        sugg.removeAllViews()
        if (secret) return
        val w = word.toString().lowercase()
        val list = if (w.isEmpty()) listOf("Olá", "Obrigado", "Bom dia")
        else {
            val pool = learned().toList() + dict
            val m = pool.filter { it.startsWith(w) && it != w }.distinct().take(3).toMutableList()
            if (m.isEmpty() || !pool.contains(w)) m.add(0, word.toString())
            m.distinct().take(3)
        }
        for ((i, s) in list.withIndex()) {
            val t = TextView(this)
            t.text = s
            t.setTextColor(if (dark) Color.WHITE else Color.BLACK)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            t.gravity = Gravity.CENTER
            t.maxLines = 1
            t.setOnClickListener {
                val ic = currentInputConnection ?: return@setOnClickListener
                if (word.isNotEmpty()) ic.deleteSurroundingText(word.length, 0)
                val out = if (shift != 0 && word.isEmpty()) s.replaceFirstChar { it.uppercaseChar() } else s
                ic.commitText("$out ", 1)
                word.setLength(0)
                if (shift == 1) { shift = 0; render() } else updateSuggestions()
            }
            sugg.addView(t, LinearLayout.LayoutParams(0, MATCH, 1f))
            if (i < list.size - 1) {
                val d = View(this); d.setBackgroundColor(if (dark) 0xFF3A3A3C.toInt() else 0xFFB5B8C0.toInt())
                sugg.addView(d, LinearLayout.LayoutParams(1, dpi(22)))
            }
        }
    }
}
