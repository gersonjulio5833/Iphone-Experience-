package com.iphoneexperience.launcher

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.Intent
import android.view.View

/**
 * Widgets REAIS de outras apps (AppWidgetHost do Android), mostrados na página "Hoje".
 * Fluxo: escolher widget → o Android pede autorização → (configuração do widget, se existir) → aparece.
 */
class WidgetHelper(private val a: HomeActivity) {
    companion object {
        const val HOST_ID = 1024
        const val REQ_BIND = 4101
        const val REQ_CONFIG = 4102
    }

    private val awm: AppWidgetManager = AppWidgetManager.getInstance(a)
    private val host = AppWidgetHost(a.applicationContext, HOST_ID)
    private var pending = -1
    private var onAdded: (() -> Unit)? = null

    fun start() { try { host.startListening() } catch (e: Exception) { } }
    fun stop() { try { host.stopListening() } catch (e: Exception) { } }

    fun ids(): MutableList<Int> {
        val raw = Prefs.get(a).sp.getString("widget_ids", "") ?: ""
        if (raw.isEmpty()) return mutableListOf()
        return raw.split(",").mapNotNull { it.toIntOrNull() }.toMutableList()
    }

    private fun save(l: List<Int>) { Prefs.get(a).sp.edit().putString("widget_ids", l.joinToString(",")).apply() }

    fun remove(id: Int) {
        val l = ids(); l.remove(id); save(l)
        try { host.deleteAppWidgetId(id) } catch (e: Exception) { }
    }

    /** Mostra a lista de widgets instalados no telemóvel. */
    fun pick(done: () -> Unit) {
        onAdded = done
        val pm = a.packageManager
        val list = try { awm.installedProviders } catch (e: Exception) { emptyList<AppWidgetProviderInfo>() }
        if (list.isEmpty()) { android.widget.Toast.makeText(a, "Não há widgets instalados", android.widget.Toast.LENGTH_SHORT).show(); return }
        val entries = list.map { p ->
            val app = try { pm.getApplicationLabel(pm.getApplicationInfo(p.provider.packageName, 0)).toString() } catch (e: Exception) { p.provider.packageName }
            Pair(app + " — " + p.loadLabel(pm), p)
        }.sortedBy { it.first.lowercase() }
        AlertDialog.Builder(a)
            .setTitle("Adicionar widget")
            .setItems(entries.map { it.first }.toTypedArray()) { _, which -> begin(entries[which].second) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun begin(p: AppWidgetProviderInfo) {
        val id = host.allocateAppWidgetId()
        pending = id
        val ok = try { awm.bindAppWidgetIdIfAllowed(id, p.provider) } catch (e: Exception) { false }
        if (ok) { configureOrFinish(id); return }
        val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
        try { a.startActivityForResult(i, REQ_BIND) } catch (e: Exception) { cancelPending() }
    }

    private fun configureOrFinish(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info?.configure != null) {
            try { host.startAppWidgetConfigureActivityForResult(a, id, 0, REQ_CONFIG, null); return } catch (e: Exception) { }
        }
        finish(id)
    }

    private fun finish(id: Int) {
        val l = ids(); if (!l.contains(id)) l.add(id); save(l)
        pending = -1
        onAdded?.invoke()
    }

    private fun cancelPending() {
        if (pending >= 0) { try { host.deleteAppWidgetId(pending) } catch (e: Exception) { } }
        pending = -1
    }

    /** Devolve true se o resultado era nosso. */
    fun onResult(req: Int, res: Int, data: Intent?): Boolean {
        if (req != REQ_BIND && req != REQ_CONFIG) return false
        val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pending) ?: pending
        if (res == Activity.RESULT_OK && id >= 0) {
            if (req == REQ_BIND) configureOrFinish(id) else finish(id)
        } else cancelPending()
        return true
    }

    fun heightPx(id: Int): Int {
        val info = awm.getAppWidgetInfo(id)
        val h = if (info != null) maxOf(info.minHeight, info.minResizeHeight) else 0
        return h.coerceIn(a.dpi(110), a.dpi(420))
    }

    fun createView(id: Int, widthPx: Int): View? {
        val info = awm.getAppWidgetInfo(id) ?: return null
        return try {
            val v: AppWidgetHostView = host.createView(a, id, info)
            val dpw = (widthPx / a.resources.displayMetrics.density).toInt()
            val dph = (heightPx(id) / a.resources.displayMetrics.density).toInt()
            v.updateAppWidgetSize(null, dpw, dph, dpw, dph)
            v
        } catch (e: Exception) { null }
    }
}
