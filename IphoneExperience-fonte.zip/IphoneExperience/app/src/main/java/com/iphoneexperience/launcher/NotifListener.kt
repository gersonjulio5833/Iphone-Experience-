package com.iphoneexperience.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Serviço de notificações: dá ao launcher (1) a lista real de notificações,
 * (2) acesso às sessões multimédia e (3) o "hospedeiro" da Dynamic Island.
 * Só funciona depois de o utilizador conceder acesso nas definições do Android.
 */
class NotifListener : NotificationListenerService() {
    companion object {
        var instance: NotifListener? = null
        val changeListeners = mutableSetOf<() -> Unit>()
        private val main = Handler(Looper.getMainLooper())

        fun snapshot(): List<StatusBarNotification> = try {
            instance?.activeNotifications?.toList() ?: emptyList()
        } catch (e: Exception) { emptyList() }

        fun notifyChange() { main.post { changeListeners.toList().forEach { it() } } }
    }

    private val screenOn = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (Prefs.get(c).lockSkin && android.provider.Settings.canDrawOverlays(c)) {
                try {
                    c.startActivity(Intent(c, ClockActivity::class.java)
                        .putExtra(ClockActivity.EXTRA_AUTO, true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_CLEAR_TOP))
                } catch (e: Exception) { }
            }
        }
    }

    override fun onListenerConnected() {
        instance = this
        try { registerReceiver(screenOn, IntentFilter(Intent.ACTION_SCREEN_ON)) } catch (e: Exception) { }
        MediaHub.start(this)
        IslandController.start(this)
        notifyChange()
    }

    override fun onListenerDisconnected() {
        instance = null
        try { unregisterReceiver(screenOn) } catch (e: Exception) { }
        MediaHub.stop()
        IslandController.stop()
        notifyChange()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) IslandController.onPosted(sbn)
        notifyChange()
    }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        IslandController.refresh()
        notifyChange()
    }
}
