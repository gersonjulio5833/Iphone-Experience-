package com.iphoneexperience.launcher

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun rounded(color: Int, radius: Float): GradientDrawable =
    GradientDrawable().apply { setColor(color); cornerRadius = radius }

fun oval(color: Int): GradientDrawable =
    GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

fun glassLight(p: Prefs): Int =
    Color.argb((255 * (0.15f + 0.45f * p.glass / 100f)).toInt(), 255, 255, 255)

fun glassDark(p: Prefs): Int =
    Color.argb((255 * (0.35f + 0.5f * p.glass / 100f)).toInt(), 28, 28, 30)

fun Context.iconView(res: Int, tint: Int, sizePx: Int): ImageView =
    ImageView(this).apply {
        setImageResource(res)
        setColorFilter(tint)
        layoutParams = ViewGroup.LayoutParams(sizePx, sizePx)
    }

fun View.pressScale(enabled: Boolean) {
    if (!enabled) return
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).start()
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}


/** Interpolador de mola amortecida (parecido com as animações do iOS). */
class SpringInterpolator(private val damping: Float = 0.72f, private val response: Float = 0.45f) :
    android.animation.TimeInterpolator {
    override fun getInterpolation(t: Float): Float {
        if (t <= 0f) return 0f
        if (t >= 1f) return 1f
        val zeta = damping.coerceIn(0.05f, 0.999f)
        val wn = (2.0 * Math.PI / response.toDouble()) * 1.0
        val wd = wn * Math.sqrt(1.0 - zeta * zeta)
        val time = t * 1.0
        val e = Math.exp(-zeta * wn * time)
        val v = 1.0 - e * (Math.cos(wd * time) + (zeta * wn / wd) * Math.sin(wd * time))
        // normaliza para terminar exactamente em 1 em t=1
        val end = 1.0 - Math.exp(-zeta * wn) * (Math.cos(wd) + (zeta * wn / wd) * Math.sin(wd))
        return (v / end).toFloat()
    }
}

val SPRING = SpringInterpolator()
val SPRING_SOFT = SpringInterpolator(0.85f, 0.5f)

fun View.spring(duration: Long = 420) = animate().setDuration(duration).setInterpolator(SPRING)

/** "Superelipse" (cantos contínuos como nos ícones do iOS). */
fun superellipse(size: Float, n: Float = 5f): android.graphics.Path {
    val p = android.graphics.Path()
    val a = size / 2f
    val steps = 120
    for (i in 0..steps) {
        val t = (i.toDouble() / steps) * 2 * Math.PI
        val ct = Math.cos(t); val st = Math.sin(t)
        val x = a + a * Math.signum(ct) * Math.pow(Math.abs(ct), 2.0 / n)
        val y = a + a * Math.signum(st) * Math.pow(Math.abs(st), 2.0 / n)
        if (i == 0) p.moveTo(x.toFloat(), y.toFloat()) else p.lineTo(x.toFloat(), y.toFloat())
    }
    p.close()
    return p
}
