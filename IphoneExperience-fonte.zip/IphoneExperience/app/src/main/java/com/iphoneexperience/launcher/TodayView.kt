package com.iphoneexperience.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

/** Anel de bateria (dados reais do BatteryManager). */
class BatteryRing(c: Context) : View(c) {
    var level = 0
        set(v) { field = v; invalidate() }
    var charging = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = minOf(w, h) * 0.78f
        val sw = s * 0.12f
        val r = RectF((w - s) / 2 + sw / 2, (h - s) / 2 + sw / 2, (w + s) / 2 - sw / 2, (h + s) / 2 - sw / 2)
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.strokeCap = Paint.Cap.ROUND
        p.color = 0x40FFFFFF
        cv.drawArc(r, 0f, 360f, false, p)
        p.color = if (level <= 20 && !charging) 0xFFFF453A.toInt() else 0xFF30D158.toInt()
        cv.drawArc(r, -90f, 360f * level / 100f, false, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER
        p.textSize = s * 0.30f
        p.typeface = Fonts.medium
        cv.drawText("$level%", w / 2, h / 2 + p.textSize * 0.35f, p)
    }
}

/** Página "Hoje" (à esquerda do ecrã inicial): relógio, bateria, multimédia e atalhos. Dados reais. */
class TodayView(private val a: HomeActivity) : FrameLayout(a), MediaHub.Listener {
    private val prefs = Prefs.get(a)
    private val ring = BatteryRing(a)
    private val mCover = ImageView(a)
    private val mTitle = TextView(a)
    private val mArtist = TextView(a)
    private val mPlay = ImageView(a)
    private val rec = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { readBattery(i) }
    }

    init {
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(a.dpi(14), 0, a.dpi(14), a.dpi(20))
        sv.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))

        val title = TextView(a)
        title.text = "Hoje"
        title.setTextColor(Color.WHITE)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
        title.typeface = Fonts.bold
        title.setShadowLayer(a.dp(3f), 0f, a.dp(1f), 0x55000000)
        title.setPadding(a.dpi(6), a.dpi(2), 0, a.dpi(10))
        col.addView(title)

        // relógio
        val clockCard = card()
        val t = TextClock(a)
        t.format24Hour = "HH:mm"; t.format12Hour = "h:mm"
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 64f)
        t.typeface = Fonts.light
        t.includeFontPadding = false
        val d = TextClock(a)
        d.format24Hour = "EEEE, d 'de' MMMM"; d.format12Hour = "EEEE, d 'de' MMMM"
        d.setTextColor(0xCCFFFFFF.toInt())
        d.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        clockCard.addView(t)
        clockCard.addView(d)
        clockCard.setOnClickListener {
            try { a.startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
        }
        col.addView(clockCard, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = a.dpi(12) })

        // linha: bateria + multimédia
        val half = (a.sw - a.dpi(28) - a.dpi(12)) / 2
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        val bat = card()
        bat.gravity = Gravity.CENTER
        bat.addView(ring, LinearLayout.LayoutParams(half - a.dpi(32), half - a.dpi(52)))
        val bl = TextView(a)
        bl.text = "Bateria"
        bl.setTextColor(0xCCFFFFFF.toInt()); bl.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        bl.gravity = Gravity.CENTER
        bat.addView(bl)
        row.addView(bat, LinearLayout.LayoutParams(half, half))

        val media = card()
        mCover.scaleType = ImageView.ScaleType.CENTER_CROP
        mCover.clipToOutline = true
        mCover.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, a.dp(10f)) }
        }
        media.addView(mCover, LinearLayout.LayoutParams(a.dpi(52), a.dpi(52)))
        mTitle.setTextColor(Color.WHITE); mTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        mTitle.typeface = Fonts.medium
        mTitle.maxLines = 1; mTitle.ellipsize = android.text.TextUtils.TruncateAt.END
        mArtist.setTextColor(0xB3FFFFFF.toInt()); mArtist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        mArtist.maxLines = 1; mArtist.ellipsize = android.text.TextUtils.TruncateAt.END
        media.addView(mTitle, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = a.dpi(8) })
        media.addView(mArtist, LinearLayout.LayoutParams(MATCH, WRAP))
        mPlay.setColorFilter(Color.WHITE)
        mPlay.setOnClickListener { MediaHub.playPause() }
        media.addView(mPlay, LinearLayout.LayoutParams(a.dpi(34), a.dpi(34)).apply { topMargin = a.dpi(4); gravity = Gravity.CENTER_HORIZONTAL })
        media.setOnClickListener {
            if (MediaHub.hasSession()) MediaHub.openApp()
            else try { a.startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (e: Exception) { }
        }
        row.addView(media, LinearLayout.LayoutParams(half, half).apply { marginStart = a.dpi(12) })
        col.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = a.dpi(12) })

        // atalhos
        val quick = card()
        quick.orientation = LinearLayout.HORIZONTAL
        quick.gravity = Gravity.CENTER
        fun q(res: Int, f: () -> Unit) = Pair(res, f)
        val items = listOf(
            q(R.drawable.ic_flashlight) { if (!Torch.toggle(a)) Toast.makeText(a, "Lanterna indisponível", Toast.LENGTH_SHORT).show() },
            q(R.drawable.ic_camera) { try { a.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } },
            q(R.drawable.ic_timer) { try { a.startActivity(Intent(AlarmClock.ACTION_SHOW_TIMERS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } },
            q(R.drawable.ic_lock) { a.startActivity(Intent(a, ClockActivity::class.java)) }
        )
        for (item in items) {
            val b = FrameLayout(a)
            b.background = oval(0x33FFFFFF)
            val iv = ImageView(a); iv.setImageResource(item.first); iv.setColorFilter(Color.WHITE)
            b.addView(iv, FrameLayout.LayoutParams(a.dpi(24), a.dpi(24), Gravity.CENTER))
            val act = item.second
            b.setOnClickListener { act() }
            b.pressScale(prefs.animations)
            quick.addView(b, LinearLayout.LayoutParams(a.dpi(54), a.dpi(54)).apply { marginStart = a.dpi(9); marginEnd = a.dpi(9) })
        }
        col.addView(quick, LinearLayout.LayoutParams(MATCH, WRAP))

        // widgets reais de outras apps
        val wBox = LinearLayout(a)
        wBox.orientation = LinearLayout.VERTICAL
        col.addView(wBox, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = a.dpi(12) })
        val wWidth = a.sw - a.dpi(28)
        for (id in a.widgets.ids()) {
            val hv = a.widgets.createView(id, wWidth) ?: continue
            val holder = FrameLayout(a)
            holder.background = rounded(glassDark(prefs), a.dp(24f))
            holder.clipToOutline = true
            holder.outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, a.dp(24f)) }
            }
            holder.addView(hv, FrameLayout.LayoutParams(MATCH, MATCH))
            if (a.isEditing()) {
                val x = FrameLayout(a)
                x.background = oval(0xFFC7C7CC.toInt())
                val xi = ImageView(a); xi.setImageResource(R.drawable.ic_close); xi.setColorFilter(0xFF3A3A3C.toInt())
                x.addView(xi, FrameLayout.LayoutParams(a.dpi(14), a.dpi(14), Gravity.CENTER))
                x.setOnClickListener { a.widgets.remove(id); a.refreshAll() }
                holder.addView(x, FrameLayout.LayoutParams(a.dpi(26), a.dpi(26), Gravity.TOP or Gravity.START).apply { leftMargin = a.dpi(8); topMargin = a.dpi(8) })
            }
            wBox.addView(holder, LinearLayout.LayoutParams(MATCH, a.widgets.heightPx(id)).apply { bottomMargin = a.dpi(12) })
        }
        val add = TextView(a)
        add.text = "+  Adicionar widget"
        add.setTextColor(Color.WHITE)
        add.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        add.typeface = Fonts.medium
        add.gravity = Gravity.CENTER
        add.background = rounded(0x44000000, a.dp(22f))
        add.setOnClickListener { a.widgets.pick { a.refreshAll() } }
        add.pressScale(prefs.animations)
        col.addView(add, LinearLayout.LayoutParams(MATCH, a.dpi(48)).apply { topMargin = a.dpi(4) })
        updateMedia()
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(a)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(a.dpi(16), a.dpi(14), a.dpi(16), a.dpi(14))
        c.background = rounded(glassDark(prefs), a.dp(24f))
        c.pressScale(prefs.animations)
        return c
    }

    private fun readBattery(i: Intent?) {
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        if (lvl >= 0) ring.level = lvl * 100 / sc
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        ring.charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun updateMedia() {
        if (!MediaHub.hasSession()) {
            mCover.setImageResource(R.drawable.ic_note)
            mCover.setColorFilter(0x88FFFFFF.toInt())
            mCover.scaleType = ImageView.ScaleType.CENTER_INSIDE
            mCover.background = rounded(0x22FFFFFF, a.dp(10f))
            mTitle.text = "Multimédia"
            mArtist.text = if (NotifListener.instance == null) "Toca para activar" else "Nada a tocar"
            mPlay.setImageResource(R.drawable.ic_play)
            return
        }
        mCover.clearColorFilter()
        mCover.scaleType = ImageView.ScaleType.CENTER_CROP
        val art = MediaHub.art()
        if (art != null) mCover.setImageBitmap(art) else { mCover.setImageResource(R.drawable.ic_note); mCover.setColorFilter(0xFFFA2D48.toInt()) }
        mTitle.text = MediaHub.title() ?: ""
        mArtist.text = MediaHub.artist() ?: ""
        mPlay.setImageResource(if (MediaHub.isPlaying()) R.drawable.ic_pause else R.drawable.ic_play)
    }

    override fun onMediaChanged() { updateMedia() }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        MediaHub.listeners.add(this)
        readBattery(a.registerReceiver(rec, IntentFilter(Intent.ACTION_BATTERY_CHANGED)))
        updateMedia()
    }

    override fun onDetachedFromWindow() {
        MediaHub.listeners.remove(this)
        try { a.unregisterReceiver(rec) } catch (e: Exception) { }
        super.onDetachedFromWindow()
    }
}
