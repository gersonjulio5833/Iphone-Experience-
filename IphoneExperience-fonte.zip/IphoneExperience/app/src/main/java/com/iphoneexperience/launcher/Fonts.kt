package com.iphoneexperience.launcher

import android.content.Context
import android.graphics.Typeface

/**
 * Tipo de letra Inter (licença OFL, incluída em assets/INTER-LICENSE.txt): a fonte livre mais próxima do SF Pro.
 * O SF original da Apple não pode ser distribuído.
 */
object Fonts {
    private lateinit var app: Context
    fun init(c: Context) { app = c.applicationContext }
    private fun load(id: Int, fallback: Typeface): Typeface =
        try { app.resources.getFont(id) } catch (e: Throwable) { fallback }
    val light: Typeface by lazy { load(R.font.inter_light, Typeface.create("sans-serif-light", Typeface.NORMAL)) }
    val regular: Typeface by lazy { load(R.font.inter_regular, Typeface.DEFAULT) }
    val medium: Typeface by lazy { load(R.font.inter_medium, Typeface.create("sans-serif-medium", Typeface.NORMAL)) }
    val semibold: Typeface by lazy { load(R.font.inter_semibold, Typeface.create("sans-serif-medium", Typeface.BOLD)) }
    val bold: Typeface by lazy { load(R.font.inter_bold, Typeface.DEFAULT_BOLD) }
    val displayBold: Typeface by lazy { load(R.font.inter_display_bold, Typeface.DEFAULT_BOLD) }
    val displayLight: Typeface by lazy { load(R.font.inter_display_light, Typeface.create("sans-serif-light", Typeface.NORMAL)) }
}

class App : android.app.Application() {
    override fun onCreate() { super.onCreate(); Fonts.init(this) }
}
