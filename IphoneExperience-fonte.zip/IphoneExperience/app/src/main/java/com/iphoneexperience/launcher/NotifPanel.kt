package com.iphoneexperience.launcher

import android.app.Notification
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.provider.Settings
import android.service.notification.StatusBarNotification
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

/**
 * Painel de notificações: mostra as notificações REAIS (NotificationListenerService),
 * agrupadas por app. Sem acesso concedido mostra apenas um aviso para o activar.
 */
class NotifPanel(private val a: HomeActivity) : FrameLayout(a) {
    private val list = LinearLayout(a)
    private val expanded = HashSet<String>()
    private var startY = 0f
    private val changed: () -> Unit = { fill() }

    init {
        setBackgroundColor(Color.argb(110, 0, 0, 0))
        setOnClickListener { a.closeNotifications() }
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(a.dpi(14), a.insetTop + a.dpi(18), a.dpi(14), 0)

        val head = FrameLayout(a)
        val t = TextView(a)
        t.text = "Notificações"
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
        t.typeface = Fonts.bold
        head.addView(t, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.CENTER_VERTICAL))
        val clear = TextView(a)
        clear.text = "Limpar"
        clear.setTextColor(0xFF64B5FF.toInt())
        clear.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        clear.setPadding(a.dpi(10), a.dpi(8), a.dpi(10), a.dpi(8))
        clear.setOnClickListener { try { NotifListener.instance?.cancelAllNotifications() } catch (e: Exception) { } }
        head.addView(clear, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL))
        col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = a.dpi(10) })

        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(a)
        sv.addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        col.addView(sv, LinearLayout.LayoutParams(MATCH, MATCH))
        addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        fill()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); NotifListener.changeListeners.add(changed); fill() }
    override fun onDetachedFromWindow() { NotifListener.changeListeners.remove(changed); super.onDetachedFromWindow() }

    private fun card(): LinearLayout {
        val c = LinearLayout(a)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(a.dpi(14), a.dpi(12), a.dpi(14), a.dpi(12))
        c.background = rounded(glassDark(Prefs.get(a)), a.dp(22f))
        c.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = a.dpi(8) }
        return c
    }

    private fun fill() {
        list.removeAllViews()
        if (NotifListener.instance == null) {
            val c = card()
            val m = TextView(a)
            m.text = "Para mostrar as notificações reais, o launcher precisa de \"Acesso a notificações\". Toca aqui para o conceder nas definições do Android."
            m.setTextColor(Color.WHITE); m.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            c.addView(m)
            c.setOnClickListener { a.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); a.closeNotifications() }
            list.addView(c)
            return
        }
        val all = NotifListener.snapshot()
            .filter { it.packageName != a.packageName && (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0 }
            .sortedByDescending { it.postTime }
        if (all.isEmpty()) {
            val m = TextView(a)
            m.text = "Sem notificações"
            m.setTextColor(0xB3FFFFFF.toInt()); m.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            m.gravity = Gravity.CENTER
            list.addView(m, LinearLayout.LayoutParams(MATCH, a.dpi(120)))
            return
        }
        for ((pkg, items) in all.groupBy { it.packageName }) {
            val open = expanded.contains(pkg)
            val shown = if (open) items else items.take(1)
            for ((i, n) in shown.withIndex()) {
                val c = card()
                c.addView(header(n, if (i == 0 && items.size > 1 && !open) items.size else 0))
                c.addView(body(n))
                c.setOnClickListener { openNotification(n) }
                list.addView(c)
            }
            if (items.size > 1) {
                val more = TextView(a)
                more.text = if (open) "Mostrar menos" else "Mostrar mais (" + (items.size - 1) + ")"
                more.setTextColor(0xFF64B5FF.toInt()); more.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                more.setPadding(a.dpi(8), 0, a.dpi(8), a.dpi(10))
                more.setOnClickListener { if (open) expanded.remove(pkg) else expanded.add(pkg); fill() }
                list.addView(more)
            }
        }
    }

    private fun appLabel(pkg: String): String = try {
        a.packageManager.getApplicationLabel(a.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun header(n: StatusBarNotification, count: Int): View {
        val h = LinearLayout(a)
        h.orientation = LinearLayout.HORIZONTAL
        h.gravity = Gravity.CENTER_VERTICAL
        val iv = ImageView(a)
        try {
            val d = a.packageManager.getApplicationIcon(n.packageName)
            iv.setImageBitmap(Icons.render(d, a.dpi(22)))
        } catch (e: Exception) { }
        h.addView(iv, LinearLayout.LayoutParams(a.dpi(22), a.dpi(22)))
        val name = TextView(a)
        name.text = appLabel(n.packageName).uppercase() + (if (count > 1) "  ($count)" else "")
        name.setTextColor(0xB3FFFFFF.toInt()); name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        h.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dpi(8) })
        val time = TextView(a)
        time.text = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(n.postTime))
        time.setTextColor(0x99FFFFFF.toInt()); time.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        h.addView(time)
        return h
    }

    private fun body(n: StatusBarNotification): View {
        val ex = n.notification.extras
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        val tt = TextView(a)
        tt.text = title; tt.setTextColor(Color.WHITE); tt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        tt.typeface = Fonts.medium
        tt.maxLines = 1; tt.ellipsize = android.text.TextUtils.TruncateAt.END
        val tx = TextView(a)
        tx.text = text; tx.setTextColor(0xE6FFFFFF.toInt()); tx.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        tx.maxLines = 3; tx.ellipsize = android.text.TextUtils.TruncateAt.END
        if (title.isNotEmpty()) box.addView(tt)
        if (text.isNotEmpty()) box.addView(tx)
        box.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = a.dpi(6) }
        return box
    }

    private fun openNotification(n: StatusBarNotification) {
        a.closeNotifications()
        try {
            n.notification.contentIntent?.send()
        } catch (e: Exception) {
            val li = a.packageManager.getLaunchIntentForPackage(n.packageName)
            if (li != null) a.startActivity(li)
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> startY = ev.rawY
            MotionEvent.ACTION_UP -> if (startY - ev.rawY > a.dpi(110)) { a.closeNotifications(); return true }
        }
        return super.dispatchTouchEvent(ev)
    }
}
