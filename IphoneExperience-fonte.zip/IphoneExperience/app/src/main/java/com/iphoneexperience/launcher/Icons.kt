package com.iphoneexperience.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.LruCache
import android.net.Uri
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Ícones estilo iOS: máscara de cantos contínuos (superelipse), brilho suave e borda fina.
 * - "Estilo iOS": as apps de sistema conhecidas (telefone, mensagens, câmara, ...) recebem um
 *   ícone desenhado por este launcher (degradé + glifo branco; calendário e relógio dinâmicos).
 * - Restantes apps: o ícone real, recortado na mesma máscara.
 */
object Icons {
    private class Look(val top: Int, val bottom: Int, val glyph: Int, val dynamic: Int = 0)

    private val cache = LruCache<String, Bitmap>(320)
    private val dynamicKeys = HashSet<String>()
    private val exec = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var looks: Map<String, Look>? = null

    private val PHONE = Look(0xFF67E57B.toInt(), 0xFF1DAA45.toInt(), R.drawable.ic_phone)
    private val CHAT = Look(0xFF6BE67C.toInt(), 0xFF1DB04A.toInt(), R.drawable.ic_chat)
    private val WEB = Look(0xFF5AC8FA.toInt(), 0xFF0A63F0.toInt(), R.drawable.ic_compass)
    private val CAM = Look(0xFFB9BBC1.toInt(), 0xFF4B4D53.toInt(), R.drawable.ic_camera)
    private val MUSIC = Look(0xFFFF6E86.toInt(), 0xFFE0112B.toInt(), R.drawable.ic_note)
    private val MAIL = Look(0xFF5CB4FF.toInt(), 0xFF0A5BE0.toInt(), R.drawable.ic_mail)
    private val MAPS = Look(0xFF86D96F.toInt(), 0xFF2A93D0.toInt(), R.drawable.ic_pin)
    private val CONTACTS = Look(0xFFC1C5CC.toInt(), 0xFF868B94.toInt(), R.drawable.ic_person)
    private val SETTINGS = Look(0xFFBBBEC4.toInt(), 0xFF6A6E75.toInt(), R.drawable.ic_gear)
    private val CALC = Look(0xFF4A4A4D.toInt(), 0xFF1B1B1D.toInt(), R.drawable.ic_calculator)
    private val FILES = Look(0xFF5CA8FF.toInt(), 0xFF0A62DE.toInt(), R.drawable.ic_folder)
    private val GALLERY = Look(0xFFFFD66E.toInt(), 0xFFFF6F4F.toInt(), R.drawable.ic_image)
    private val STORE = Look(0xFF5CCBFB.toInt(), 0xFF0A78F5.toInt(), R.drawable.ic_bag)
    private val WEATHER = Look(0xFF4FB4FF.toInt(), 0xFF1F6FE0.toInt(), R.drawable.ic_sun)
    private val CALENDAR = Look(Color.WHITE, Color.WHITE, 0, 1)
    private val CLOCK = Look(0xFF1B1B1D.toInt(), 0xFF000000.toInt(), 0, 2)

    private fun resolveLooks(ctx: Context): Map<String, Look> {
        looks?.let { return it }
        val pm = ctx.packageManager
        val m = HashMap<String, Look>()
        fun add(i: Intent, l: Look) {
            val list = try { pm.queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY) } catch (e: Exception) { emptyList() }
            val pkg = list.map { it.activityInfo.packageName }.firstOrNull { it != "android" } ?: return
            if (!m.containsKey(pkg)) m[pkg] = l
        }
        fun sel(cat: String) = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, cat)
        add(Intent(Intent.ACTION_DIAL), PHONE)
        add(sel(Intent.CATEGORY_APP_MESSAGING), CHAT)
        add(sel(Intent.CATEGORY_APP_BROWSER), WEB)
        add(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), CAM)
        add(sel(Intent.CATEGORY_APP_MUSIC), MUSIC)
        add(sel(Intent.CATEGORY_APP_EMAIL), MAIL)
        add(sel(Intent.CATEGORY_APP_MAPS), MAPS)
        add(sel(Intent.CATEGORY_APP_CONTACTS), CONTACTS)
        add(Intent(Settings.ACTION_SETTINGS), SETTINGS)
        add(sel(Intent.CATEGORY_APP_CALCULATOR), CALC)
        add(sel(Intent.CATEGORY_APP_FILES), FILES)
        add(sel(Intent.CATEGORY_APP_GALLERY), GALLERY)
        add(sel(Intent.CATEGORY_APP_MARKET), STORE)
        add(sel(Intent.CATEGORY_APP_WEATHER), WEATHER)
        add(sel(Intent.CATEGORY_APP_CALENDAR), CALENDAR)
        add(Intent(AlarmClock.ACTION_SHOW_ALARMS), CLOCK)
        looks = m
        return m
    }

    // ------------------------------------------------------------------ ícones personalizados (imagem escolhida)

    fun customFile(ctx: Context, pkg: String): File = File(File(ctx.filesDir, "icons"), "$pkg.png")
    fun hasCustom(ctx: Context, pkg: String): Boolean = customFile(ctx, pkg).exists()

    fun importCustom(ctx: Context, pkg: String, uri: Uri): Boolean = try {
        val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: throw IllegalStateException()
        val side = minOf(src.width, src.height)
        val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
        val out = Bitmap.createScaledBitmap(sq, 512, 512, true)
        val f = customFile(ctx, pkg)
        f.parentFile?.mkdirs()
        f.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
        true
    } catch (e: Exception) { false }

    fun removeCustom(ctx: Context, pkg: String) { customFile(ctx, pkg).delete() }

    fun clearCustomAll(ctx: Context) { File(ctx.filesDir, "icons").listFiles()?.forEach { it.delete() } }

    private fun keyOf(ctx: Context, app: AppInfo, size: Int): String =
        app.id + "@" + size + "@" + Prefs.get(ctx).iconStyle + "@" + customFile(ctx, app.pkg).lastModified()

    /** Limpa os ícones que mudam com o tempo (calendário e relógio). */
    fun clearDynamic() {
        synchronized(dynamicKeys) { for (k in dynamicKeys) cache.remove(k); dynamicKeys.clear() }
    }

    // ------------------------------------------------------------------ desenho

    private fun finish(content: Bitmap, size: Int): Bitmap {
        val s = size.toFloat()
        val c0 = Canvas(content)
        // brilho suave no topo
        val gl = Paint(Paint.ANTI_ALIAS_FLAG)
        gl.shader = LinearGradient(0f, 0f, 0f, s * 0.6f, 0x22FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c0.drawRect(0f, 0f, s, s, gl)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val mask = superellipse(s)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.WHITE
        c.drawPath(mask, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        c.drawBitmap(content, 0f, 0f, p)
        // borda interior muito fina
        val b = Paint(Paint.ANTI_ALIAS_FLAG)
        b.style = Paint.Style.STROKE
        b.strokeWidth = maxOf(1f, s * 0.012f)
        b.color = 0x30FFFFFF
        c.save(); c.scale(0.992f, 0.992f, s / 2, s / 2); c.drawPath(mask, b); c.restore()
        return out
    }

    private fun gradientBg(c: Canvas, s: Float, top: Int, bottom: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, s, top, bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, s, s, p)
    }

    private fun drawGlyph(ctx: Context, c: Canvas, s: Float, res: Int, scale: Float = 0.58f, tint: Int = Color.WHITE) {
        val d = ctx.getDrawable(res)?.mutate() ?: return
        d.setTint(tint)
        val g = (s * scale).toInt()
        val o = ((s - g) / 2f).toInt()
        // ligeira sombra
        val sh = ctx.getDrawable(res)?.mutate()
        if (sh != null) {
            sh.setTint(0x33000000)
            sh.setBounds(o, o + (s * 0.012f).toInt() + 1, o + g, o + g + (s * 0.012f).toInt() + 1)
            sh.draw(c)
        }
        d.setBounds(o, o, o + g, o + g)
        d.draw(c)
    }

    private fun dynamicIcon(ctx: Context, look: Look, size: Int): Bitmap {
        val s = size.toFloat()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val now = Date()
        if (look.dynamic == 1) {
            c.drawColor(Color.WHITE)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.textAlign = Paint.Align.CENTER
            p.color = 0xFFFF3B30.toInt()
            p.typeface = Fonts.medium
            p.textSize = s * 0.17f
            val wd = SimpleDateFormat("EEE", Locale.getDefault()).format(now).uppercase().trimEnd('.')
            c.drawText(wd, s / 2, s * 0.27f, p)
            p.color = Color.BLACK
            p.typeface = Fonts.light
            p.textSize = s * 0.56f
            val day = Calendar.getInstance().get(Calendar.DAY_OF_MONTH).toString()
            c.drawText(day, s / 2, s * 0.80f, p)
        } else {
            c.drawColor(0xFF000000.toInt())
            val cx = s / 2; val cy = s / 2; val r = s * 0.42f
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = Color.WHITE
            c.drawCircle(cx, cy, r, p)
            p.color = Color.BLACK
            p.strokeCap = Paint.Cap.ROUND
            p.strokeWidth = s * 0.014f
            for (i in 0 until 60) {
                val a = Math.toRadians(i * 6.0)
                val big = i % 5 == 0
                val r1 = r * (if (big) 0.82f else 0.9f); val r2 = r * 0.95f
                p.strokeWidth = s * (if (big) 0.022f else 0.01f)
                c.drawLine(cx + (Math.sin(a) * r1).toFloat(), cy - (Math.cos(a) * r1).toFloat(),
                    cx + (Math.sin(a) * r2).toFloat(), cy - (Math.cos(a) * r2).toFloat(), p)
            }
            val cal = Calendar.getInstance()
            val h = (cal.get(Calendar.HOUR) + cal.get(Calendar.MINUTE) / 60.0) * 30.0
            val m = cal.get(Calendar.MINUTE) * 6.0
            p.strokeWidth = s * 0.04f
            c.drawLine(cx, cy, cx + (Math.sin(Math.toRadians(h)) * r * 0.5f).toFloat(), cy - (Math.cos(Math.toRadians(h)) * r * 0.5f).toFloat(), p)
            p.strokeWidth = s * 0.028f
            c.drawLine(cx, cy, cx + (Math.sin(Math.toRadians(m)) * r * 0.76f).toFloat(), cy - (Math.cos(Math.toRadians(m)) * r * 0.76f).toFloat(), p)
            p.color = 0xFFFF9500.toInt()
            c.drawCircle(cx, cy, s * 0.03f, p)
        }
        return bmp
    }

    private fun dominant(b: Bitmap): Int {
        val t = Bitmap.createScaledBitmap(b, 12, 12, true)
        var r = 0L; var g = 0L; var bl = 0L; var n = 0L
        for (y in 0 until 12) for (x in 0 until 12) {
            val px = t.getPixel(x, y)
            val a = Color.alpha(px)
            if (a < 128) continue
            r += Color.red(px); g += Color.green(px); bl += Color.blue(px); n++
        }
        if (n == 0L) return 0xFF6A6E75.toInt()
        return Color.rgb((r / n).toInt(), (g / n).toInt(), (bl / n).toInt())
    }

    private fun shade(c: Int, f: Float): Int =
        Color.rgb((Color.red(c) * f).toInt().coerceIn(0, 255), (Color.green(c) * f).toInt().coerceIn(0, 255), (Color.blue(c) * f).toInt().coerceIn(0, 255))

    /** Desenha o ícone real de uma app na máscara do launcher. */
    fun render(d: Drawable, size: Int): Bitmap {
        val content = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(content)
        if (d is AdaptiveIconDrawable) {
            val o = (size * 0.25f).toInt()
            val bg = d.background
            val fg = d.foreground
            if (bg != null) { bg.setBounds(-o, -o, size + o, size + o); bg.draw(c) } else c.drawColor(Color.WHITE)
            if (fg != null) { fg.setBounds(-o, -o, size + o, size + o); fg.draw(c) }
        } else {
            val tmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val tc = Canvas(tmp)
            val inset = (size * 0.12f).toInt()
            d.setBounds(inset, inset, size - inset, size - inset)
            d.draw(tc)
            val dom = dominant(tmp)
            val lum = (0.299 * Color.red(dom) + 0.587 * Color.green(dom) + 0.114 * Color.blue(dom)) / 255.0
            val top = if (lum > 0.85) Color.WHITE else shade(dom, 1.15f)
            val bot = if (lum > 0.85) 0xFFF1F1F4.toInt() else shade(dom, 0.85f)
            gradientBg(c, size.toFloat(), top, bot)
            c.drawBitmap(tmp, 0f, 0f, null)
        }
        return finish(content, size)
    }

    private fun sync(ctx: Context, app: AppInfo, size: Int): Bitmap {
        val style = Prefs.get(ctx).iconStyle
        val key = keyOf(ctx, app, size)
        cache.get(key)?.let { return it }
        var look: Look? = null
        if (style == 1) look = resolveLooks(ctx)[app.pkg]
        val bmp: Bitmap
        val cf = customFile(ctx, app.pkg)
        val custom = if (cf.exists()) try { BitmapFactory.decodeFile(cf.absolutePath) } catch (e: Exception) { null } else null
        if (custom != null) {
            val content = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            Canvas(content).drawBitmap(custom, null, Rect(0, 0, size, size), Paint(Paint.FILTER_BITMAP_FLAG))
            bmp = finish(content, size)
        } else if (look != null) {
            if (look.dynamic != 0) {
                bmp = finish(dynamicIcon(ctx, look, size), size)
                synchronized(dynamicKeys) { dynamicKeys.add(key) }
            } else {
                val content = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                val c = Canvas(content)
                gradientBg(c, size.toFloat(), look.top, look.bottom)
                drawGlyph(ctx, c, size.toFloat(), look.glyph)
                bmp = finish(content, size)
            }
        } else {
            val d = try {
                ctx.packageManager.getActivityIcon(ComponentName(app.pkg, app.cls))
            } catch (e: Exception) { ctx.packageManager.defaultActivityIcon }
            bmp = render(d, size)
        }
        cache.put(key, bmp)
        return bmp
    }

    fun load(ctx: Context, app: AppInfo, size: Int, cb: (Bitmap) -> Unit) {
        val app2 = ctx.applicationContext
        val key = keyOf(app2, app, size)
        cache.get(key)?.let { cb(it); return }
        exec.execute {
            val b = sync(app2, app, size)
            main.post { cb(b) }
        }
    }

    /** Ícone de pasta: fundo translúcido com miniaturas 3x3 das apps. */
    fun folder(ctx: Context, apps: List<AppInfo>, size: Int, cb: (Bitmap) -> Unit) {
        val app2 = ctx.applicationContext
        exec.execute {
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val bg = Paint(Paint.ANTI_ALIAS_FLAG)
            bg.color = 0x66FFFFFF
            c.drawPath(superellipse(size.toFloat()), bg)
            val pad = size * 0.11f
            val cell = (size - 2 * pad) / 3f
            val mini = (cell * 0.84f).toInt().coerceAtLeast(8)
            for ((i, a) in apps.take(9).withIndex()) {
                val b = sync(app2, a, mini)
                val x = pad + (i % 3) * cell + (cell - mini) / 2f
                val y = pad + (i / 3) * cell + (cell - mini) / 2f
                c.drawBitmap(b, x, y, null)
            }
            main.post { cb(bmp) }
        }
    }
}
