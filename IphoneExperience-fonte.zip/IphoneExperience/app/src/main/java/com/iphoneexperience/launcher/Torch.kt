package com.iphoneexperience.launcher

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper

/** Lanterna real (CameraManager.setTorchMode, sem permissões extra). */
object Torch {
    var on = false
        private set
    val listeners = mutableSetOf<(Boolean) -> Unit>()
    private var registered = false
    private var camId: String? = null

    private fun cm(ctx: Context): CameraManager = ctx.getSystemService(CameraManager::class.java)

    private fun findId(ctx: Context): String? {
        camId?.let { return it }
        camId = try {
            val m = cm(ctx)
            m.cameraIdList.firstOrNull {
                val c = m.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (e: Exception) { null }
        return camId
    }

    fun init(ctx: Context) {
        if (registered) return
        val app = ctx.applicationContext
        try {
            cm(app).registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == findId(app)) {
                        on = enabled
                        listeners.toList().forEach { it(enabled) }
                    }
                }
            }, Handler(Looper.getMainLooper()))
            registered = true
        } catch (e: Exception) { }
    }

    fun available(ctx: Context): Boolean = findId(ctx) != null

    fun toggle(ctx: Context): Boolean {
        val id = findId(ctx) ?: return false
        return try { cm(ctx).setTorchMode(id, !on); true } catch (e: Exception) { false }
    }
}
